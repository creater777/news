<?php
    $root = $_SERVER['DOCUMENT_ROOT'];
    require $root.'/main/lib/ideal_db.php';
    require $root.'/main/lib/func_lib.php';
    $field = 'headline,title,description,keywords';
    $table = 'mainday';
    $url = 'news';
    include $root.'/main/block/header.php';
?>
<div class="content news">
    <div class="crumbs">
        <ul>
            <li><a href="/">Главная</a></li>
            <li><p><?php echo $myheadline; ?></p></li>
        </ul>
    </div>
    <?php
        index_prev($mysqli);
        include $root.'/main/block/partners.php';
        echo '</div>';
        include $root.'/main/block/footer.php';
    ?>