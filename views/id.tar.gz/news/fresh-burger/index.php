<?php
    $root = $_SERVER['DOCUMENT_ROOT'];
    require $root.'/main/lib/ideal_db.php';
    require $root.'/main/lib/func_lib.php';
    $field = 'headline,title,description,keywords';
    $table = 'newsday';
    $url = 'fresh-burger';
    include $root.'/main/block/header.php';
?>
<div class="content recall">
    <div class="crumbs">
        <ul>
            <li><a href="/">Главная</a></li>
            <li><a href="/news">Лента новостей</a></li>
            <li><p><?php echo $myheadline; ?></p></li>
        </ul>
    </div>
    <div class="col-1 news-det">
        <?php
            detail_news($mysqli,$url);
        ?>
    </div>
    <?php
        include $root.'/main/block/partners.php';
        echo '</div>';
        include $root.'/main/block/footer.php';
    ?>