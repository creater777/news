<?php
    $root = $_SERVER['DOCUMENT_ROOT'];
    require $root.'/main/lib/ideal_db.php';
    require $root.'/main/lib/func_lib.php';
    $url = 'keytering';
    $field = 'headline,title,description,keywords,imgname,other,content';
    $table = 'mainday';
    include $root.'/main/block/header.php';
?>
<div class="content white-menu one-pr">
    <div class="crumbs">
        <ul>
            <li><a href="/">Главная</a></li>
            <li><p>
                <?php echo $myrow['headline']; ?>
            </p></li>
        </ul>
    </div>

    <div id="prinfo-2" class="col-1 border-indent program-info active">
        <div class="green-border">
            <h3><?php echo $myrow['headline']; ?></h3>
            <b><span><?php echo $myrow['other']; ?></span></b>
            <?php echo $myrow['content']; ?>
        </div>

        <div>
            <div align="left">
                <img src="/main/image/keytering/1.jpg" width="350" height="480" style="padding-top: 10px;">
                <img src="/main/image/keytering/2.jpg" width="350" height="235" style="padding-top: 10px;">
                <img src="/main/image/keytering/3.jpg" width="350" height="235" style="padding-top: 10px;">
            </div>
            <div align="left">
           		<img src="/main/image/keytering/4.jpg" width="350" height="480" style="padding-top: 10px;">
            </div>
            
        </div>

    </div>
<?php
    include $root.'/main/block/checkout_full.php';
    include $root.'/main/block/popup_checkout_full.php';
    include $root.'/main/block/partners.php';
    echo '</div>';
    include $root.'/main/block/footer.php';
?>