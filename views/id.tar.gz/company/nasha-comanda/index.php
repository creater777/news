<?php
    header("HTTP/1.1 301 Moved Permanently");
    header("Location: http://ideal-day.com/company/nasha-comanda/ideal-wellness-couch/");


    // $root = $_SERVER['DOCUMENT_ROOT'];
    // require $root.'/main/lib/ideal_db.php';
    // require $root.'/main/lib/func_lib.php';
    // $field = 'headline,title,description,keywords';
    // $table = 'mainday';
    // $url = "nasha-comanda";
    // include $root.'/main/block/header.php';
?>
<div class="content company">
    <div class="crumbs">
        <ul>
            <li><a href="/">Главная</a></li>
            <?php
                $field = "title,other";
                $url = "o-companii";
                $myrow = unloading_main($mysqli,$field,$table,$url);
            ?>
            <li><?php echo '<a href="/'.$myrow['other'].'">'.$myrow['title'].'</a>'; ?></li>
            <li><p><?php echo $myheadline; ?></p></li>
        </ul>
    </div>
    <div class="main-img">
        <?php
            $field = 'title,addtitle,bgimg,twotitle';
            $table = 'idealcompany';
            $url = "nasha-comanda";
            $myrow = unloading_main($mysqli,$field,$table,$url);
            echo '<img src="/main/image/company/'.$myrow['bgimg'].'" alt="Ideal Day"><div class="green-bg"><h1>'.$myrow['title'].'</h1><p>'.$myrow['addtitle'].'</p></div>';
        ?>
    </div>
    <div class="pink-bg">
        <h2><?php echo $myrow['twotitle']; ?></h2>
    </div>
    <div class="inset">
        <?php
            inset_our_team($mysqli);
        ?>
    </div>
    <div class="col-1 border-indent" style="margin-top: 10px;">
    <?php
        info_our_team($mysqli);
        echo '</div>';
        include $root.'/main/block/partners.php';
        echo '</div>';
        include $root.'/main/block/footer.php';
        include $root.'/main/block/popup_checkout_full.php';
    ?>