<?php
    $root = $_SERVER['DOCUMENT_ROOT'];
    $comanda_page=2;
    include $root.'/company/nasha-comanda/comanda.php';
?>
