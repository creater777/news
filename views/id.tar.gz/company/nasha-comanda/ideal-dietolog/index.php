<?php
    $root = $_SERVER['DOCUMENT_ROOT'];
    $comanda_page=3;
    include $root.'/company/nasha-comanda/comanda.php';
?>
