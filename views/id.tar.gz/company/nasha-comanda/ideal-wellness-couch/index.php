<?php
    $root = $_SERVER['DOCUMENT_ROOT'];
    $comanda_page=1;
    include $root.'/company/nasha-comanda/comanda.php';
?>
