<?php
    $root = $_SERVER['DOCUMENT_ROOT'];
    require $root.'/main/lib/ideal_db.php';
    require $root.'/main/lib/func_lib.php';
    $field = 'headline,title,description,keywords,imgname';
    $table = 'mainday';
    $url = "o-nas";
    include $root.'/main/block/header.php';
?>
<div class="content company">
    <div class="crumbs">
        <ul>
            <li><a href="/">Главная</a></li>
            <?php
                $field = "title,other";
                $url = "o-companii";
                $myrow = unloading_main($mysqli,$field,$table,$url);
            ?>
            <li><?php echo '<a href="/'.$myrow['other'].'">'.$myrow['title'].'</a>'; ?></li>
            <li><p><?php echo $myheadline; ?></p></li>
        </ul>
    </div>
    <div class="col-1 border-indent">
        <div id="info-1" class="green-border photo active">
            <?php
                $parent = $myrow['other'];
                $field = 'content,other,imgname';
                $url = "o-nas";
                $myrow = unloading_main($mysqli,$field,$table,$url);
                echo '<img src="/main/image/'.$parent.'/'.$url.'/'.$myrow['imgname'].'" alt="'.$myrow['other'].'"><h3 class="pink">'.$myrow['other'].'</h3><p>'.$myrow['content'].'</p>';
            ?>
        </div>
    </div>
    <div class="col-1 about-us center">
        <div class="green-bg-logo">
            <img src="/main/img/white-logo.png" alt="ideal-day">
        </div>
        <div class="pink-bg-op">
            <?php
                about_us($mysqli);
            ?>
        </div>
        <div>

            <video width="400" height="300" controls poster="http://ideal-day.com/main/img/video-o-nas.png" src="http://ideal-day.com/main/videos/company/11_ideal_day_dostavka.mp4"></video>

        </div>

   </div>




    <?php
        include $root.'/main/block/partners.php';
        echo '</div>';
        include $root.'/main/block/footer.php';
        include $root.'/main/block/popup_checkout_full.php';
    ?>