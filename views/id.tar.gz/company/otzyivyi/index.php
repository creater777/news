<?php
    require "../../main/lib/ideal_db.php";
    require "../../main/lib/func_lib.php";
    $field = 'title,description,keywords,headline';
    $table = 'mainday';
    $url = "recall";
    require "../../main/lib/unloading_main.php";
    $myheadline = $myrow['headline'];
    include "../../main/block/header.php";
?>
<div class="content recall">
    <div class="crumbs">
        <ul>
            <li><a href="/">Главная</a></li>
            <?php
                $field = "title,other";
                $url = "o-companii";
                include "../../main/lib/unloading_main.php";
            ?>
            <li><?php echo '<a href="/'.$myrow['other'].'">'.$myrow['title'].'</a>'; ?></li>
            <li><p><?php echo $myheadline; ?></p></li>
        </ul>
    </div>
    <?php
        recall($mysqli);
        include '../../main/block/partners.php';
        echo '</div>';
        include '../../main/block/footer.php';
        include '../../main/block/popup_checkout_full.php';
    ?>