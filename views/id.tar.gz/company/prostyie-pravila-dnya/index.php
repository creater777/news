<?php
    $root = $_SERVER['DOCUMENT_ROOT'];
    require $root.'/main/lib/ideal_db.php';
    require $root.'/main/lib/func_lib.php';
    $field = 'headline,title,description,keywords';
    $table = 'mainday';
    $url = "prostyie-pravila-dnya";
    include $root.'/main/block/header.php';
?>
<div class="content rules-day">
    <div class="crumbs">
        <ul>
            <li><a href="/">Главная</a></li>
            <?php
                $field = "title,other";
                $url = "o-companii";
                $myrow = unloading_main($mysqli,$field,$table,$url);
            ?>
            <li><?php echo '<a href="/'.$myrow['other'].'">'.$myrow['title'].'</a>'; ?></li>
            <li><p><?php echo $myheadline; ?></p></li>
        </ul>
    </div>
    <div class="main-img">
        <?php
            $field = 'headline,imgname,content,other';
            $table = 'mainday';
            $url = "prostyie-pravila-dnya";
            $myrow = unloading_main($mysqli,$field,$table,$url);
            echo '<img src="/main/image/company/'.$myrow['imgname'].'" alt="'.$myrow['headline'].'"><div class="green-bg"><h1>'.$myrow['headline'].' '.$myrow['other'].'</h1><p>'.$myrow['content'].'</p></div>';
        ?>
    </div>
    <div class="col-1 border-indent">
        <div class="green-border photo">
            <?php
                rules_day($mysqli);
            ?>
        </div>
    </div>
        <?php
            include $root.'/main/block/partners.php';
            echo '</div>';
            include $root.'/main/block/footer.php';
            include $root.'/main/block/popup_checkout_full.php';
        ?>