<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Акция: Идеальная форма в Grandee!</title>
    <meta name="description" content="Корпоративная программа доставки Ideal Day5+. При заказе 21 дня Вы получите 2 дня питания в подарок. Экономия от программы Ideal Day 5+ до 8000 руб. Каждый день станет идеальным!">
    <meta name="keywords" content="правильное питание, правильное питание меню, правильное питание на день, идеальное тело за месяц, идеальное тело за 30 дней, корпоративное питание в москве, корпоративное питание москва, питание в офис, обеды в офис">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="style.css">
    <script src="/main/js/jquery-2.1.1.min.js"></script>
    <script src="main.js"></script>
    <script src="/main/js/stats/ya.js"></script>
    <script src="/main/js/stats/gl.js"></script>
    <link rel="icon" type="image/png" href="/main/img/favicon.png">
</head>
<body>
    <div class="header">
        <div class="top main">
            <div class="left">
                <a href="/"><img src="/main/img/logo.png" alt="Ideal Day"></a>
            </div>
            <div class="right">
                <span class="pink">+7 999 985 85 85</span>
                <!-- <a class="button" href="#" rel="nofollow">Заказать звонок</a> -->
            </div>
        </div>
        <div class="big-bg">
            <div class="main">
                <div class="white-block">
                    <span class="green h2">При любой поездке с персональным водителем Grandee</span>
                    <span class="green h2">Вы получите сертификат</span>
                    <h1 class="pink p"> на 2 000 рублей на любую программу правильного здорового питания Ideal-day!</h1>
                    <!--<strong class="green h3">Стройность за компанию!</strong>-->
                </div>
            </div>
        </div>
    </div>
    <div class="one-lid main">
        <div class="col-2">
            <div class="pink-border">
                <h2 class="green h2">Остались вопросы?</h2>
                <h2 class="green h3">Заполните форму для обратной связи. Мы свяжемся с Вами в любое удобное для Вас время и ответим на все Ваши вопросы.</h2>
                <form method="post" action="/main/processing/landing_one.php" id="lid-one">
                    <input type="text" name="name" id="name-one" placeholder="Ваше имя и фамилия">
                    <input type="text" name="phone" id="phone-one" placeholder="Ваш номер телефона">
                    <input type="email" name="email" id="email-one" placeholder="Адрес эл. почты">
                    <select name="time" id="time-one">
                        <option disabled="disabled" selected="selected">Время обратного звонка</option>
                        <option value="09:00–12:00">09:00–12:00</option>
                        <option value="12:00–15:00">12:00–15:00</option>
                        <option value="15:00–18:00">15:00–18:00</option>
                        <option value="18:00–21:00">18:00–21:00</option>
                    </select>
                    <span></span>
                    <input type="submit" id="submit" value="Заказать сейчас"><small></small>
                </form>
            </div>
        </div>
        <div class="col-2 addition">
            <span class="green h1">Условия акции</span>
            <h3><ol>
<li>Закажите автомобиль с персональным водителем Grandee в период с 31 декабря 2015 года по 2 января 2016 года.</li>
<br>
<li>Получите сертификат на любую программу Ideal day на сумму 2000 рублей у водителя Grandee.</li></li>
<br>
<li>Срок действия сертификата до 15.02.2016 г.</li>
<br>
<li>Сертификат не подлежит обмену на денежное вознаграждение.</li>
        </ol></h3>
        </div>
        <span class="green h3">Совершенство движения – в Grandee! </span>
<br>
Подробнее о том, как заказать автомобиль Grandee на <a href="www.grandeecar.com">www.grandeecar.com</a>
    </div>
    </div>
    </div>
    <div class="footer">
        <div class="top main">
            <div class="left">
                <img src="/main/img/logo.png" alt="Ideal Day">
            </div>
            <div class="right">
                <span class="pink">+7 999 985 85 85</span>
                <!-- <a class="button" href="#" rel="nofollow">Заказать звонок</a> -->
            </div>
        </div>
    </div>
</body>
</html>