$(document).ready(function(){
    // validate
    var validName = /^([\ba-zа-я\.'\b+]){2,15}([ ]?){0,1}([\ba-zа-я-\.'\b+]?){1,15}([ ]?){0,1}([\ba-zа-я-\.'\b+]?){1,15}$/img;
    var validEmail = /^([\w\.\-_]+)?\w+@[\w-_]+(\.\w+){1,}$/igm;
    var validPhone = /^([\++]?){0,1}([0-9]){9,13}$/;

    function validSelect(formSelect){
        var select = formSelect;
        if(select.val() == null){
            errors = true;
            select.removeClass('valid');
            select.addClass('error');
        }else{
            select.removeClass('error');
            select.addClass('valid');
        }
    };
    function validate(form,valid){
        function validForm(){
            if(form.val() != ''){
                if(form.val().search(valid) == 0){
                    form.removeClass('error').addClass('valid');
                }else{
                    form.removeClass('valid').addClass('error');
                }
            }else{
                form.removeClass('valid').addClass('error');
            }
        };
        form.blur(function(){
            validForm();
        });
        form.keyup(function(){
            validForm();
        });
    };

    // ajaxForm
    function ajaxForm(form,handler){
        form.submit(function(){
            var errors = false;
            $(this).find('input:not(#submit),select').each(function(){
                if($.trim($(this).val()) == ''){
                    errors = true;
                    $(this).addClass('error');
                }else{
                    $(this).removeClass('error');
                    $(this).addClass('valid');
                }
                validSelect(form.find('select'));
            });
            if(!errors){
                var data = form.serialize();
                $.ajax({
                    url: '/main/processing/'+handler+'.php',
                    type: 'POST',
                    data: data,
                    beforeSend: function(){
                        form.find('small').text('Отправляю...');
                    },
                    success: function(res){
                        if(res == 1){
                            form.find('input:not(#submit)').val('');
                            form.find('input:not(#submit)').removeClass('valid');
                            form.find('small').text('Спасибо! Ваша заявка принята!');
                        }else{
                            form.find('small').text('Ошибка отправки');
                        }
                    },
                    error: function(){
                        form.find('small').text('Ошибка отправки');
                    }
                });
            };
            return false;
        });
    }

    // send
    var lidOne = $('#lid-one');
    var lidTwo = $('#lid-two');
    var nameOne = $('#name-one');
    var emailOne = $('#email-one');
    var phoneOne = $('#phone-one');
    var nameTwo = $('#name-two');
    var emailTwo = $('#email-two');
    var phoneTwo = $('#phone-two');


    validate(nameOne,validName);
    validate(emailOne,validEmail);
    validate(phoneOne,validPhone);
    validate(nameTwo,validName);
    validate(emailTwo,validEmail);
    validate(phoneTwo,validPhone);

    ajaxForm(lidOne,'landing_one');
    ajaxForm(lidTwo,'landing_one');
});