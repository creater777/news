<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Акция 21+2: Здоровое корпоративное питание - Ideal Day</title>
    <meta name="description" content="Корпоративная программа доставки Ideal Day5+. При заказе 21 дня Вы получите 2 дня питания в подарок. Экономия от программы Ideal Day 5+ до 8000 руб. Каждый день станет идеальным!">
    <meta name="keywords" content="правильное питание, правильное питание меню, правильное питание на день, идеальное тело за месяц, идеальное тело за 30 дней, корпоративное питание в москве, корпоративное питание москва, питание в офис, обеды в офис">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="style.css">
    <script src="/main/js/jquery-2.1.1.min.js"></script>
    <script src="main.js"></script>
    <script src="/main/js/stats/ya.js"></script>
    <script src="/main/js/stats/gl.js"></script>
    <link rel="icon" type="image/png" href="/main/img/favicon.png">
</head>
<body>
    <div class="header">
        <div class="top main">
            <div class="left">
                <a href="/"><img src="/main/img/logo.png" alt="Ideal Day"></a>
            </div>
            <div class="right">
                <span class="pink">+7 999 985 85 85</span>
                <!-- <a class="button" href="#" rel="nofollow">Заказать звонок</a> -->
            </div>
        </div>
        <div class="big-bg">
            <div class="main">
                <div class="white-block">
                    <span class="green h2">Больше <strong>страсти к красоте</strong> -</span>
                    <span class="green h1">больше подарков!</span>
                    <h1 class="pink p">Корпоративная программа доставки правильного питания IDEAL DAY</h1>
                    <!--<strong class="green h3">Стройность за компанию!</strong>-->
                </div>
            </div>
        </div>
    </div>
    <div class="one-lid main">
        <div class="col-2">
            <div class="pink-border">
                <h2 class="green h3">Выгоднее, чем бизнес-ланчи, полезнее, чем фаст-фуд и удобнее, чем готовить дома!</h2>
                <form method="post" action="/main/processing/landing_one.php" id="lid-one" onsubmit ="yaCounter31001171.reachGoal('send-form'); return true;">
                    <input type="text" name="name" id="name-one" placeholder="Ваше имя и фамилия">
                    <input type="text" name="phone" id="phone-one" placeholder="Ваш номер телефона">
                    <input type="email" name="email" id="email-one" placeholder="Адрес эл. почты">
                    <select name="time" id="time-one">
                        <option disabled="disabled" selected="selected">Время обратного звонка</option>
                        <option value="09:00–12:00">09:00–12:00</option>
                        <option value="12:00–15:00">12:00–15:00</option>
                        <option value="15:00–18:00">15:00–18:00</option>
                        <option value="18:00–21:00">18:00–21:00</option>
                    </select>
                    <span></span>
                    <input type="submit" id="submit" value="Заказать сейчас"><small></small>
                </form>
            </div>
        </div>
        <div class="col-2 addition">
            <span class="green h1">Внимание, <strong>Акция 21+2</strong>!</span>
            <h2><strong>Закажите</strong> курс IDEAL DAY на 21 день - получите <strong>питание на 2 дня в подарок</strong>!</h2>
            <!--<p>Как сочетать страсть к карьерному росту, рабочие авралы до поздней ночи, пробки <strong>Москвы и правильное питание</strong>?!</p>
            <h3>Идеальный тим-билдинг: объединяйтесь с коллегами!</h3>
            <h2>Закажите свой идеальный рабочий день в <span class="green">Ideal Day</span>!</h2>-->
            <h3 class="pink h3">Экономия до 8000 руб!</h3>
        </div>
    </div>
    <div class="menu main">
        <div class="green-bg-op">
            <span class="h1">Идеальное меню</span>
        </div>
        <div class="pink-bg-op">
            <div class="col-5">
                <span>завтрак</span>
                <p>Каша мультизлаковая с грушевым соте и корицей</p>
            </div>
            <div class="col-5">
                <span>второй завтрак</span>
                <p>Фритатта с томатами и моцареллой</p>
            </div>
            <div class="col-5 three">
                <span>обед</span>
                <p>Стейк из фермерской индейки (зернового откорма) гриль с пряным булгуром</p>
            </div>
            <div class="col-5 last">
                <span>полдник</span>
                <p>Ванильные сырники с апельсиновым конфитюром своего производства</p>
            </div>
            <div class="col-5 last">
                <span>ужин</span>
                <p>Фермерский мини-цыпленок запеченый с инжиром и розмарином</p>
            </div>
        </div>
    </div>
    <div class="team main center">
        <span class="h1 pink upper">Идеальная команда</span>
        <div class="col-4 left">
            <div class="wrap">
                <img src="/main/image/event/zdorovoe-corporativnoe-pitanie/team-1.jpg" alt="Идеальный wellness-коучер">
            </div>
            <span class="small pink">Идеальный wellness-коучер</span>
            <span class="small green upper">Анна Козырева</span>
            <span class="small pink">создательница проекта Ideal Day</span>
        </div>
        <div class="col-2">
            <div class="wrap">
                <img src="/main/image/event/zdorovoe-corporativnoe-pitanie/team-2.jpg" alt="Идеальная команда поваров">
            </div>
            <span class="small pink">Идеальная команда поваров</span>
            <span class="small green upper">Иван Фролов</span>
            <span class="small pink">шеф-повар</span>
            <span class="small green upper">Владимир Беловицкий</span>
            <span class="small pink">су-шеф</span>
        </div>
        <div class="col-4 right">
            <div class="wrap">
                <img src="/main/image/event/zdorovoe-corporativnoe-pitanie/team-3.jpg" alt="Идеальный диетолог">
            </div>
            <span class="small pink">Идеальный диетолог</span>
            <span class="small green upper">Елена Штих</span>
            <span class="small pink">сертифицированный специалист по диетическому и спортивному питанию</span>
        </div>
    </div>
    <div class="pink-img-bg">
        <div class="main center">
            <span class="h3">Почему мы считаем, что <strong>курс на 21 день</strong> - золотой стандарт для коррекции фигуры?</span>
            <p><strong>Обновление</strong> клеток в нашем организме составляет ок <strong>3х недель</strong>.</p>
            <p>По данным ВОЗ, <strong>пищевые пристрастия</strong> перестраиваются в течение 14 дней: за это время можно нормализовать страсть к сладкому, соленому и жирному.</p>
            <p>Еще около 7 дней необходимо, чтобы закрепить приобретенные <strong>правильные привычки питания</strong> и <strong>избежать срывов</strong>!</p>
            <p>В результате за 21 день организм перестраивается, избавляется от токсинов и внутренних отеков - <strong>Вы становитесь стройнее</strong>, энергичнее, исчезает вялость и cонливость по утрам, улучшается качество кожи и волос.</p>
        </div>
    </div>
    <div class="girl main">
        <div class="col-35 center">
            <img src="/main/image/event/zdorovoe-corporativnoe-pitanie/girl.jpg" alt="Желаемый результат">
        </div>
        <div class="col-65 green h3">
            <p>Всего за 3 недели с помощью команды профессионалов Ideal Day <strong>Вы добьетесь</strong> того, о чем так долго мечтали!</p>
            <h3>Каждый день станет идеальным!</h3>
        </div>
    </div>
    <div class="recall main">
        <span class="h1 pink upper center">Отзывы наших клиентов</span>
        <div class="col-35 center">
            <img src="/main/image/event/zdorovoe-corporativnoe-pitanie/recall.jpg" alt="Отзывы">
        </div>
        <div class="col-65">
            <span class="h3 pink upper center">САЛОН "КУКЛЫ"</span>
            <p>Ideal Day - это отличный сервис для салонов красоты и клиник. Наша сфера связана с эстетикой, поэтому фигура мастера, врача - всегда в центре внимания. Ideal Day позволяет правильно организовать 5-разовое питание всех работников нашего салона! Прекрасное меню, прекрасные результаты!</p>
        </div>
    </div>
    <div class="regulations main">
        <div class="green-bg-op">
            <h3 class="h3 upper center">Простые правила дня = Идеальное тело всю жизнь</h3>
            <p>Питание Ideal Day имеет строго научную основу, поэтому совершенно безопасно и эффективно. Вы защищены от срывов и повторного набора веса, похудения за счёт мышечной массы и любого вреда для здоровья. Наше меню полностью состоит из фермерских продуктов. Все курсы питания разработаны при участии известного диетолога, доцента РУДН. Чтобы эффект от программ был максимальный, вам необходимо соблюдать ПРОСТЫЕ ПРАВИЛА ДНЯ:</p>
        </div>
        <div class="col-1">
            <div class="col-3">
                <div class="pink-bg-op upper center"><h3>5 приемов пищи каждый день</h3></div>
                <div class="desc one">
                    <p>Каждая программа Ideal Day состоит из 5 приемов пищи, и это не случайно! Только дробное питание одобрено Всемирной Организацией Здравоохранения. Что это значит? Вы не должны испытывать чувство голода, иначе это приводит к нарушению метаболизма и неправильной работе пищеварительной и нервной системы - и как следствие, к патологии подкожно-жировой клетчатки. Говоря проще, вы легко набираете лишний вес, переедаете, чувствуете себя усталыми по утрам.</p>
                    <p>Пятиразовое питание  Ideal Day исключает чувство голода, и все системы организма начинают работать гармонично. В каждом пакете Ideal Day боксы с завтраком, вторым завтраком, обедом, полдником, ужином. Программы имеют разную калорийность в зависимости от ваших целей! Наше меню содержит достаточное количество белков, жиров и углеводов, баланс сахара и соли, правильный набор микроэлементов, необходимых вам для отличного физического и эмоционального состояния.</p>
                    <p class="pink">ВАЖНО! Мы настоятельно рекомендуем не включать в ваш рацион другие продукты питания, так как это сильно повлияет на эффективность курса коррекции фигуры!</p>
                    <span></span>
                </div>
            </div>
            <div class="col-3">
                <div class="pink-bg-op upper center"><h3>Не более 3х часов между приемами пищи</h3></div>
                <div class="desc two">
                    <p>Жировые клетки - это энергетическое депо нашего организма. Для того, чтобы жироваяклетка "отдавала" энергию, а не откладывала калории про запас, необходимо питаться каждые 2,5 - 3 часа. Только такой режим питания позволяет избежать скачков инсулина, который и регулирует энергообмен жировой клетки. Мы стремимся научить вас правильным привычкам питания, а не просто временно изменить ваше меню. Каждый контейнер Ideal Day имеет подпись: например, "завтрак" или "ужин".</p>
                    <p class="pink">ВАЖНО! Нельзя менять местами блюда из разных приемов пищи или съедать их вместе. Питаться необходимо в той последовательности, как подписаны ваши контейнеры, каждые 2,5-3 часа. Нельзя увеличивать промежутки между приемами пищи. Только такой режим питания позволит в кратчайшие сроки перестроить метаболизм.</p>
                    <span></span>
                </div>
            </div>
            <div class="col-3">
                <div class="pink-bg-op upper center"><span>Завтракайте!</span></div>
                <div class="desc">
                    <p>Утро - это начало нового дня, чтобы день прошел идеально необходимо завтракать! Завтрак - это самый важный прием пищи. Он позволяет поднять упавший за ночь уровень инсулина. Если вы позавтракаете правильно, то в течение дня будете гарантированно защищены от тянущего чувства голода.</p>
                    <p>Доставка Ideal Day начинается с 5 утра, чтобы вы могли насладиться теплым, только что приготовленным завтраком перед началом рабочего дня. Но завтрак не должен быть тяжелым. К 11:30-12:00 организм максимально активизируется, поэтому вы испытываете легкое чувство голода. Дополнительный завтрак позволяет получить нужную дозу энергии для дневных свершений и не переедать во-второй половине дня.</p>
                </div>
            </div>
        </div>
        <div class="col-1">
            <div class="col-3">
                <div class="pink-bg-op upper center"><h3>Насладитесь ужином</h3></div>
                <div class="desc one">
                    <p>Мы считаем, что нельзя пропускать ужин и не есть после 18:00. Вы не должны испытывать чувство голода.</p>
                    <p>Правильно: последний прием пищи за 2,5-3 часа до сна.</p>
                    <p class="pink">ВАЖНО! На ужин мы всегда предлагаем блюда богатые белком. Углеводы имеют свойство превращаться в жир, поэтому их следует избегать в вечернее время. Это относится и к фруктам!</p>
                    <span></span>
                </div>
            </div>
            <div class="col-3">
                <div class="pink-bg-op upper center"><span>Без соли и сахара</span></div>
                <div class="desc two">
                    <p>По статистике, современный человек съедает соли в 20 раз больше суточной нормы. А сахара в 100 раз больше допустимой нормы! Избыточное потребление соли приводит к внутренним отекам и гипертонии, сахар - брожению, диабету и раздражительности. Не зря его называют главным "наркотиком" современности.</p>
                    <p class="pink">ВАЖНО! Нельзя подсаливать и подслащивать питание Ideal Day! За 10 дней полностью перестроятся ваши вкусовые рецепторы.</p>
                    <span></span>
                </div>
            </div>
            <div class="col-3">
                <div class="pink-bg-op upper center"><span>Вода - это жизнь</span></div>
                <div class="desc">
                    <p>Соблюдайте питьевой режим! Не менее 2-х литров чистой воды в день. Сократите употребление кофе, откажитесь от лимонадов и других газированных напитков. (В 300 мл кока-колы - 23 чайных ложки сахара!)</p>
                    <p class="pink">ВАЖНО! Утром после сна выпить стакан чистой воды (идеально: минеральной без газа с долькой лимона, если нет повышенной кислотности и язвы желудка) - это запустит обменные процессы.</p>
                </div>
            </div>
        </div>
        <div class="col-1">
            <div class="green-bg-op">
                <span class="small upper center">Придерживаясь этих простых правил, вы легко достигнете желаемого результата!</span>
            </div>
        </div>
    </div>
    <div class="two-lid main">
        <div class="pink-border">
            <span class="pink h3">Остались вопросы?</span>
            <p class="pink">Заполните форму для обратной связи. Мы свяжемся с Вами в любое удобное для Вас время и ответим на все Ваши вопросы.</p>
            <form method="post" action="" id="lid-two" onsubmit ="yaCounter31001171.reachGoal('send-form'); return true;">
                <div class="col-2"><div class="r-indent"><input type="text" name="name" id="name-two" placeholder="Ваше имя и фамилия"></div></div>
                <div class="col-2"><div class="l-indent"><input type="text" name="phone" id="phone-two" placeholder="Ваш номер телефона"></div></div>
                <div class="col-2"><div class="r-indent"><input type="email" name="email" id="email-two" placeholder="Адрес эл. почты"></div></div>
                <div class="col-2">
                    <div class="l-indent">
                        <select name="time" id="time-two">
                            <option disabled="disabled" selected="selected">Время обратного звонка</option>
                            <option value="09:00–12:00">09:00–12:00</option>
                            <option value="12:00–15:00">12:00–15:00</option>
                            <option value="15:00–18:00">15:00–18:00</option>
                            <option value="18:00–21:00">18:00–21:00</option>
                        </select>
                        <span></span>
                    </div>
                </div>
                <div class="col-2"><div class="r-indent"><input type="submit" id="submit" value="Отправить"><small></small></div></div>
                <div class="col-2"><div class="l-indent"><p class="green">Выгоднее, чем бизнес-ланчи, полезнее, чем фаст-фуд и удобнее, чем готовить дома!</p></div></div>
            </form>
        </div>
    </div>
    <div class="footer">
        <div class="top main">
            <div class="left">
                <img src="/main/img/logo.png" alt="Ideal Day">
            </div>
            <div class="right">
                <span class="pink">+7 999 985 85 85</span>
                <!-- <a class="button" href="#" rel="nofollow">Заказать звонок</a> -->
            </div>
        </div>
    </div>
</body>
</html>