<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Акция: Пригласите своего близкого стать участником проекта Ideal Day!</title>
    <meta name="description" content="">
    <meta name="keywords" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="style.css">
    <script src="/main/js/jquery-2.1.1.min.js"></script>
    <script src="main.js"></script>
    <script src="/main/js/stats/ya.js"></script>
    <script src="/main/js/stats/gl.js"></script>
    <link rel="icon" type="image/png" href="/main/img/favicon.png">
</head>
<body>
    <div class="header">
        <div class="main top">
            <div class="left">
                <a href="/"><img src="/main/img/logo.png" alt="Ideal Day"></a>
            </div>
            <div class="right">
                <span class="pink">+7 999 985 85 85</span>
                <!-- <a class="button" href="#" rel="nofollow">Заказать звонок</a> -->
            </div>
        </div>
        <div class="headline mb-ind">
            <div class="img">
                <img src="/main/image/event/priglasi_druga/top-bg.jpg" alt="Идеальный друг">
            </div>
            <div class="pink-bg-op">
                <div class="main center white">
                    <span class="h1 bold">Акция: ИДЕАЛЬНЫЙ ДРУГ!</span>
                    <p class="h3 light">Пригласите своего близкого человека стать участником проекта Ideal Day и получите день питания в подарок!</p>
                </div>
            </div>
        </div>
    </div>
    <div class="main one-lid mb-ind">
        <div class="white-bg col-60">
            <div class="pink-brd center">
                <span class="h2 light pink">Больше страсти к красоте - больше подарков! *</span>
                <form method="post" action="" id="one-form" onsubmit ="yaCounter31001171.reachGoal('send-form'); return true;">
                    <div class="customer">
                        <input name="name" placeholder="Ваше имя и фамилия" type="text">
                        <input name="phone" placeholder="Ваш номер телефона" type="text">
                        <input name="email" placeholder="Адрес эл. почты" type="email">
                        <div class="select">
                            <select name="time">
                                <option disabled="disabled" selected="selected">Время обратного звонка</option>
                                <option value="09:00–12:00">09:00–12:00</option>
                                <option value="12:00–15:00">12:00–15:00</option>
                                <option value="15:00–18:00">15:00–18:00</option>
                                <option value="18:00–21:00">18:00–21:00</option>
                            </select>
                            <span></span>
                        </div>
                    </div>
                    <a href="#" class="p green">Пригласить друга</a>
                    <div class="friend">
                        <input name="name" data-name="friend" placeholder="Имя и фамилия друга" type="text">
                        <input name="phone" data-phone="friend" placeholder="Номер телефона друга" type="text">
                    </div>
                    <input value="Заказать сейчас" type="submit"><small></small>
                    <span class="info pink upper">* акция действует при покупке курса вашим другом от 10 дней.</span>
                </form>
            </div>
        </div>
    </div>
    <div class="main team">
        <div class="white-bg col-1 mb-ind">
            <div class="green-brd center">
                <span class="h1 upper pink">Идеальная команда</span>
                <div class="col-4 left">
                    <img src="/main/image/event/zdorovoe-corporativnoe-pitanie/team-1.jpg" alt="Идеальный wellness-коучер">
                    <span class="small pink">Идеальный wellness-коучер</span>
                    <span class="small green upper">Анна Козырева</span>
                    <span class="small pink">создательница проекта Ideal Day</span>
                </div>
                <div class="col-2">
                    <img src="/main/image/event/zdorovoe-corporativnoe-pitanie/team-2.jpg" alt="Идеальная команда поваров">
                    <span class="small pink">Идеальная команда поваров</span>
                    <span class="small green upper">Иван Фролов</span>
                    <span class="small pink">шеф-повар</span>
                    <span class="small green upper">Владимир Беловицкий</span>
                    <span class="small pink">су-шеф</span>
                </div>
                <div class="col-4 right">
                    <img src="/main/image/event/zdorovoe-corporativnoe-pitanie/team-3.jpg" alt="Идеальный диетолог">
                    <span class="small pink">Идеальный диетолог</span>
                    <span class="small green upper">Елена Штих</span>
                    <span class="small pink">сертифицированный специалист по диетическому и спортивному питанию</span>
                </div>
            </div>
        </div>
    </div>
    <div class="main center mb-ind">
        <span class="h1 upper pink">Идеальные программы</span>
    </div>
    <div class="op-green-bg">
        <div class="main">
            <div class="text left">
                <img src="img/prog-1.jpg" alt="">
                <p><span>Стабильный результат</span><span>Comfort lady / Comfort gentleman</span>Программа «COMFORT» подразумевает именно комфортное и, главное, стабильное похудение. Индивидуально подобранная калорийность - это чувство  сытости, в течение всего дня, и, в тоже время, ежедневное снижение веса. Данную  программу вы можете совмещать с легкими физическими нагрузками.</p>
                <p><span>Быстрый результат</span><span>Extreme lady / Extreme gentleman</span>Ускоряются процессы обмена и очищения организма, вырабатывается привычка к регулярному дробному питанию. Уже через несколько дней, вы будете ощущать легкость, одежда станет сидеть более свободно, а весы покажут на несколько килограмм меньше.</p>
            </div>
        </div>
    </div>
    <div class="op-green-bg">
        <div class="main">
            <div class="text right">
                <img src="img/prog-2.jpg" alt="">
                <p><span>Фитнес-диета</span><span>Fitness lady / Fitness gentleman</span>Баланс белков, жиров, углеводов и минеральных веществ обеспечит вам прилив сил, и вы сможете быстро восстанавливаться после занятий спортом.<br>ОБРАТИТЕ ВНИМАНИЕ: Наша программа может быть рассчитана не только на снижение, но и на увеличение массы тела, в зависимости от ваших фитнес-целей.</p>
                <p><span>Стройность на всю жизнь</span><span>Normal lady / Normal gentleman</span>ЭФФЕКТИВНОСТЬ. Вы никогда не будете переживать, что набрали несколько лишних килограммов из-за рабочего стресса или праздников. Вы получаете вкусную, красиво оформленную еду, приготовленную нашим шеф-поваром из высококачественных  натуральных фермерских продуктов. Вы получаете здоровую сбалансированную еду, для  правильной работы вашего организма и отличного самочувствия.</p>
            </div>
        </div>
    </div>
    <div class="op-green-bg">
        <div class="main">
            <div class="text left">
                <img src="img/prog-3.jpg" alt="">
                <p><span>Вегетерианство / Пост</span><span>Vegan lady / Vegan gentleman</span>ЭФФЕКТИВНОСТЬ. Сбалансированное меню, на основе продуктов растительного происхождения, содержит все необходимые питательные вещества и минералы, для правильного обмена веществ. Так как наш диетолог не рекомендует исключать молочные продукты животного происхождения (молоко, йогурты, творог, сыры), по вашему желанию, мы можем оставить их в вашем рационе.</p>
                <p><span>Идеально и индивидуально</span>Еда - это высокие отношения. Поэтому мы стремимся максимально учитывать Ваши вкусы, образ жизни и особенности состояния здоровья! Ради Вас мы готовы полностью изменить наше стандартное меню.<br>Именно с этой целью мы ввели в курс Ideal Day "Индивидуальную программу": наша команда - диетолог, фитнес-тренер, шеф-повар и wellness коуч- подберут для Вас идеальные продукты, напитки и методы их приготовления! Еда должна приносить максимум удовольствия! Максимум пользы Потому что каждый день должен быть идеальным.</p>
            </div>
        </div>
    </div>
    <div class="main two-lid mb-ind">
        <div class="white-bg">
            <div class="pink-brd">
                <span class="h1 pink">Остались вопросы?</span>
                <form method="post" action="" id="two-form" onsubmit ="yaCounter31001171.reachGoal('send-form'); return true;">
                    <div class="customer">
                        <div class="col-2">
                            <div class="r-indent">
                                <input name="name" placeholder="Ваше имя и фамилия" type="text">
                            </div>
                        </div>
                        <div class="col-2">
                            <div class="l-indent">
                                <input name="phone" placeholder="Ваш номер телефона" type="text">
                            </div>
                        </div>
                        <div class="col-2">
                            <div class="r-indent">
                                <input name="email" placeholder="Адрес эл. почты" type="email">
                            </div>
                        </div>
                        <div class="col-2">
                            <div class="select l-indent">
                                <select name="time">
                                    <option disabled="disabled" selected="selected">Время обратного звонка</option>
                                    <option value="09:00–12:00">09:00–12:00</option>
                                    <option value="12:00–15:00">12:00–15:00</option>
                                    <option value="15:00–18:00">15:00–18:00</option>
                                    <option value="18:00–21:00">18:00–21:00</option>
                                </select>
                                <span></span>
                            </div>
                        </div>
                    </div>
                    <div class="col-1 center">
                        <a href="#" class="p green">Пригласить друга</a>
                    </div>
                    <div class="friend">
                        <div class="col-2">
                            <div class="r-indent">
                                <input name="name" data-name="friend" placeholder="Имя и фамилия друга" type="text">
                            </div>
                        </div>
                        <div class="col-2">
                            <div class="l-indent">
                                <input name="phone" data-phone="friend" placeholder="Номер телефона друга" type="text">
                            </div>
                        </div>
                    </div>
                    <div class="col-2 m-center">
                        <input value="Заказать сейчас" type="submit"><small></small>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <div class="main center mb-ind">
        <span class="h1 upper pink">Отзывы наших клиентов</span>
    </div>
    <div class="op-pink-bg review">
        <div class="main">
            <div class="text left">
                <img src="img/review-1.jpg" alt="">
                <p><span>Корнелия Манго, Певица</span></p>
                <p>Я прошла 10-дневный курс Extreme Lady, цель которого помочь организму быстро перестроиться на правильный режим и сдвинуть вес с мертвой точки. Программа рассчитана на 950 ккал ежедневного 5-разового питания. За это время я похудела на 3 кг. Спасибо Ideal Day, что учли мои пожелания и составили для меня индивидуальное меню! У меня диабет - и это всегда большая сложность с подбором продуктов. Меня приучили к правильному режиму, я поняла, как правильно готовить блюда! Я на верном пути!</p>
            </div>
        </div>
    </div>
    <div class="op-pink-bg review">
        <div class="main">
            <div class="text right">
                <img src="img/review-2.jpg" alt="">
                <p><span>Лана Клер, Певица</span></p>
                <p>Мне в какой-то мере повезло с телосложением. Спортом занимаюсь с детства и, возможно, поэтому никогда не страдала лишним весом. Но, как и любой девушке, мне бы хотелось похудеть на пару килограммов, которые в принципе раньше могла сбросить, если голодала. Именно - голодала! Потому что никакие диеты я не приемлю! Само ощущение, что нужно себя в чем-то ограничивать претит мне. Поэтому питание Ideal day подошло для меня идеально! Каждый день что-то новое, очень вкусное и совсем не диетическое! А правильно составленное меню повлияло на то, что я наконец избавилась от этих ненавистных килограммов! Спасибо Ideal Day!</p>
            </div>
        </div>
    </div>
    <div class="op-pink-bg review">
        <div class="main">
            <div class="text left">
                <img src="img/review-3.jpg" alt="">
                <p><span>Джанина Мусаева, Генеральный директор клиники "Laser Lounge Clinic"</span></p>
                <p>Мы по достоинству оценили корпоративное питание и доставку компании Ideal Day. Всегда оперативно, всегда высокое качество продуктов и оригинальные рецепты. Удобные и красивые боксы! Концепция полностью соответствует ритму мегаполиса: экономит время и силы. Очень важно, что такое питание позволяет сотрудникам поддерживать идеальную форму.</p>
            </div>
        </div>
    </div>
    <div class="main center mb-ind">
        <a href="#" class="btn h1 center">Заказать программу</a>
    </div>
    <div class="footer">
        <div class="main top">
            <div class="left">
                <img src="/main/img/logo.png" alt="Ideal Day">
            </div>
            <div class="right">
                <span class="pink">+7 999 985 85 85</span>
                <!-- <a class="button" href="#" rel="nofollow">Заказать звонок</a> -->
            </div>
        </div>
    </div>
</body>
</html>