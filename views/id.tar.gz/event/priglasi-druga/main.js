$(document).ready(function(){
    // inviteFriend
    function iFr(lid){
        var form = '.'+lid+'-lid';
        var fr = $(form+' .friend');
        $(form+' a.green').click(function(){
            if(fr.hasClass('active')){
                fr.slideUp(300);
                fr.removeClass('active');
            }else{
                fr.slideDown(300);
                fr.addClass('active');
            };
            return false;
        });
    }
    iFr('one');
    iFr('two');

    // validateForm
    var validName = /^([\ba-zа-я\.'\b+]){2,15}([ ]?){0,1}([\ba-zа-я-\.'\b+]?){1,15}([ ]?){0,1}([\ba-zа-я-\.'\b+]?){1,15}$/img;
    var validEmail = /^([\w\.\-_]+)?\w+@[\w-_]+(\.\w+){1,}$/igm;
    var validPhone = /^([\++]?){0,1}([0-9]){9,13}$/;

    function validSelect(formSelect){
        var select = formSelect;
        if(select.val() == null){
            errors = true;
            select.removeClass('valid');
            select.addClass('error');
        }else{
            select.removeClass('error');
            select.addClass('valid');
        }
    };
    function validate(f,i,n,valid){
        var form = $('#'+f+'-form').find('.'+i+' input[name='+n+']');
        function validForm(){
            if(form.val() != ''){
                if(form.val().search(valid) == 0){
                    form.removeClass('error').addClass('valid');
                }else{
                    form.removeClass('valid').addClass('error');
                }
            }else{
                form.removeClass('valid').addClass('error');
            }
        };
        form.blur(function(){
            validForm();
        });
        form.keyup(function(){
            validForm();
        });
        if(form.val() != ''){
            if(form.val().search(valid) == 0){
                form.removeClass('error').addClass('valid');
            }else{
                form.removeClass('valid').addClass('error');
            }
        }
    };

    validate('one','customer','name',validName);
    validate('one','customer','phone',validPhone);
    validate('one','customer','email',validEmail);
    validate('one','friend','name',validName);
    validate('one','friend','phone',validPhone);
    validate('two','customer','name',validName);
    validate('two','customer','phone',validPhone);
    validate('two','customer','email',validEmail);
    validate('two','friend','name',validName);
    validate('two','friend','phone',validPhone);

    // ajaxForm
    function ajaxForm(f,h){
        var form = $('#'+f+'-form');
        form.submit(function(){
            var error = false;
            function withoutFriend(w){
                form.find('.'+w+' input,.customer select').each(function(){
                    validSelect(form.find('.customer select'));
                    if($(this).val() == '' || $(this).val() == null || $(this).hasClass('valid') == false){
                        $(this).addClass('error');
                        error = true;
                    }else{
                        $(this).removeClass('error');
                    }
                })
            };
            if($('.friend').hasClass('active')){
                withoutFriend('customer');
                withoutFriend('friend');
                var sendData = {
                    nameC: $(this).find('.customer input[name=name]').val(),
                    phoneC: $(this).find('.customer input[name=phone]').val(),
                    emailC: $(this).find('.customer input[name=email]').val(),
                    timeC: $(this).find('.customer select[name=time]').val(),
                    nameF: $(this).find('.friend input[name=name]').val(),
                    phoneF: $(this).find('.friend input[name=phone]').val(),
                    friend: 'active'
                }
            }else{
                withoutFriend('customer');
                var sendData = {
                    nameC: $(this).find('.customer input[name=name]').val(),
                    phoneC: $(this).find('.customer input[name=phone]').val(),
                    emailC: $(this).find('.customer input[name=email]').val(),
                    timeC: $(this).find('.customer select[name=time]').val(),
                    friend: 'noactive'
                }
            };
            if(error === false){
                $.ajax({
                    url: '/main/processing/'+h+'.php',
                    type: 'POST',
                    data: {'data': sendData},
                    dataType: 'json',
                    beforeSend: function(){
                        form.find('small').text('Отправляю...');
                    },
                    success: function(res){
                        if(res == '1'){
                            location.href = window.location.protocol+'//'+window.location.host+'/event/thank-you/';
                        }else{
                            form.find('small').text('Ошибка отправки');
                        }
                    },
                    error: function(){
                        form.find('small').text('Ошибка отправки');
                    }
                });
            }
            return false;
        });
    }

    // sendForm
    ajaxForm('one','event_friend');
    ajaxForm('two','event_friend');

    // clickScrollTop
    $('.btn.h1').click(function(){
        var hh = $('.header').height();
        $('body,html').animate({scrollTop:hh},800);
        return false;
    });
});