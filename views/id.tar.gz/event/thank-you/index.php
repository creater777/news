<?php
    $root = $_SERVER['DOCUMENT_ROOT'];
    require $root.'/main/lib/ideal_db.php';
    require $root.'/main/lib/func_lib.php';
    $url = 'index';
    $field = 'title,description,keywords,headline,content,fbtitle,fbdescription,fbimage';
    $table = 'mainday';
    include $root.'/main/block/header.php';
?>
<div class="content thank-you center">
    <a href="/"><img src="/main/img/big-logo.png" alt="Ideal Day"></a>
    <p class="pink">Благодарим за заявку!</p>
    <p class="pink">Ожидайте звонка, с Вами свяжутся в указанное Вами время.</p>
    <p class="mt">Узнайте больше о наших программах питания</p>
    <a href="/programs/" class="btn big upper center">Подробнее о программах Ideal Day</a>
    <p class="sm">Следите за нашими новостями в социальных сетях:</p>
    <div class="soc green">
        <a class="in" href="https://instagram.com/ideal.day/" target="_blank" rel="nofollow"></a>
        <!-- <a class="tw" href="https://twitter.com/" target="_blank" rel="nofollow"></a> -->
        <a class="fb" href="https://www.facebook.com/pages/Ideal-Day/846500995413544" target="_blank" rel="nofollow"></a>
        <!-- <a class="vk" href="http://vk.com/" target="_blank" rel="nofollow"></a> -->
    </div>
</div>
<?php
    include $root.'/main/block/footer.php';
?>