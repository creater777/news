<?php
    $root = $_SERVER['DOCUMENT_ROOT'];
    require $root.'/main/lib/ideal_db.php';
    require $root.'/main/lib/func_lib.php';
    $url = 'contact';
    $field = 'title,description,keywords,headline,content';
    $table = '`mainday`';
    include $root.'/main/block/header.php';
?>
<div class="content">
    <div class="crumbs">
        <ul>
            <li><a href="/">Главная</a></li>
            <li><p>Контакты</p></li>
        </ul>
    </div>
    <div class="col-1 border-indent contact">
        <div class="green-border">
            <div class="col-2 m0 center">
                <h2 class="pink">Контакты</h2>
                <div class="contact-info address">
                    <p>Россия</p>
                    <div class="region">
                        <a href="#">Регион <span>Москва</span></a>
                        <ul>
                            <li>Москва</li>
                            <li>Тула</li>
                        </ul>
                    </div>
                </div>
                <div class="contact-info phone-number">
                    <p>+7 999 985 85 85</p>
                </div>
                <div class="contact-info email-address">
                    <p><a href="mailto:info@ideal-day.com" class="black-link">info@ideal-day.com</a></p>
                </div>
                <div class="contact-info soc green">
                    <a class="in" href="https://instagram.com/ideal.day/" target="_blank" rel="nofollow"></a>
                    <!-- <a class="tw" href="https://twitter.com/" target="_blank" rel="nofollow"></a> -->
                    <a class="fb" href="https://www.facebook.com/pages/Ideal-Day/846500995413544" target="_blank" rel="nofollow"></a>
                    <!-- <a class="vk" href="http://vk.com/" target="_blank" rel="nofollow"></a> -->
                </div>
            </div>
            <div class="col-2 m0">
                <h2 class="pink center">Связаться с нами</h2>
                <form method="POST" action="" onsubmit ="yaCounter31001171.reachGoal('send-form'); return true;"  >
                    <label for="name">Ваше Имя</label>
                    <input type="text" name="name" id="name-contact">
                    <div class="min-marg">
                        <p class="col-2 ind m0">
                            <label for="email">Ваш Email</label>
                            <input type="email" name="email" id="email-contact">
                        </p>
                    </div>
                    <div class="min-marg">
                        <p class="col-2 ind m0">
                            <label for="phone">Ваш номер телефона</label>
                            <input type="text" name="phone" id="phone-contact">
                        </p>
                    </div>
                    <label for="message">Ваше сообщение</label>
                    <textarea name="message" id="message" rows="7"></textarea>
                    <input type="submit" id="submit" value="Отправить">
                    <small></small>
                </form>
            </div>
        </div>
    </div>
    <?php
        include $root.'/main/block/checkout_full.php';
        include $root.'/main/block/partners.php';
    ?>
</div>
<?php
    include $root.'/main/block/footer.php';
    include $root.'/main/block/popup_checkout_full.php';
?>



<?php

if((isset($_POST['name']))&&(isset($_POST['phone']))&&(isset($_POST['email']))&&(isset($_POST['message']))){
$to = "ideal.day2015@yandex.ru";
$subject = "ЗАЯВКА НА ЗВОНОК";
$name = "ИМЯ:\n".htmlspecialchars($_POST['name'])."<br/>";
$phone = "\nТЕЛЕФОН:\n".htmlspecialchars($_POST['phone'])."<br/>";
$email = "\nEMAIL:\n".htmlspecialchars($_POST['email'])."<br/>";
$message = "\nСООБЩЕНИЕ:\n".htmlspecialchars($_POST['message'])."<br/>";
$headers= "MIME-Version: 1.0\r\n";
$headers .= "Content-type: text/html; charset=utf-8\r\n";
$headers .= "From: Ideal Day <info@ideal-day.com> \r\n";

mail($to, $subject, $name.$phone.$email.$message, $headers);

}

?>