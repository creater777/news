<?php
    $root = $_SERVER['DOCUMENT_ROOT'];
    $active_programs_slide = 5;
    $title = 'Программа питания "Стройность на всю жизнь" - Ideal Day';
    include $root.'/programs/programs.php';
?>
