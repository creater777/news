<?php
    $root = $_SERVER['DOCUMENT_ROOT'];
    $active_programs_slide = 6;
    $title = 'Программа питания "Идеально и индивидуально" - Ideal Day';
    include $root.'/programs/programs.php';
?>
