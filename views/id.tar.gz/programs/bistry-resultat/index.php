<?php
    $root = $_SERVER['DOCUMENT_ROOT'];
    $active_programs_slide = 3;
    $title = 'Программа питания "Быстрый результат" - Ideal Day';
    include $root.'/programs/programs.php';

?>
