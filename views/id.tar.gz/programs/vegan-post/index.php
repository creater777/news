<?php
    $root = $_SERVER['DOCUMENT_ROOT'];
    $active_programs_slide = 7;
    $title = 'Программа питания "Вегетарианство/пост" - Ideal Day';
    include $root.'/programs/programs.php';
?>
