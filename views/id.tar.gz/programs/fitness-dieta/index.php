<?php
    $root = $_SERVER['DOCUMENT_ROOT'];
    $active_programs_slide = 4;
    $title = 'Программа питания "Фитнес - диета" - Ideal Day';
    include $root.'/programs/programs.php';
?>
