<?php
header("HTTP/1.1 301 Moved Permanently");
header("Location: http://ideal-day.com/programs/stabilniy-resultat/");
?>

    // $root = $_SERVER['DOCUMENT_ROOT'];
    // require $root.'/main/lib/ideal_db.php';
    // require $root.'/main/lib/func_lib.php';
    // $url = 'programs';
    // $field = 'headline,title,description,keywords';
    // $table = 'mainday';
    // include $root.'/main/block/header.php';

<div class="content programs one-pr">
    <div class="crumbs">
        <ul>
            <li><a href="/">Главная</a></li>
            <li><p>
                <?php echo $myrow['headline']; ?>
            </p></li>
        </ul>
    </div>
    <div class="program-slider">
        <a href="#" class="arr prev" rel="nofollow"><span></span><em></em></a>
        <a href="#" class="arr next" rel="nofollow"><span></span><em></em></a>
        <ul>
            <?php pr_slide($mysqli); ?>
        </ul>
        <div class="front-slider">
            <div class="wrap">
                <?php front_slide($mysqli); ?>
            </div>
        </div>
    </div>
    <div class="kсal min-marg">
        <div class="col-6 ind"><span>950 <small>ккал/день</small></span><b>2500 <small>руб.</small></b></div>
        <div class="col-6 ind"><span>1200 <small>ккал/день</small></span><b>2700 <small>руб.</small></b></div>
        <div class="col-6 ind"><span>1500 <small>ккал/день</small></span><b>3000 <small>руб.</small></b></div>
        <div class="col-6 ind"><span>1800 <small>ккал/день</small></span><b>3300 <small>руб.</small></b></div>
        <div class="col-6 ind"><span>2100 <small>ккал/день</small></span><b>3600 <small>руб.</small></b></div>
        <div class="col-6 ind"><span>2400 <small>ккал/день</small></span><b>4000 <small>руб.</small></b></div>
    </div>
<?php
    pr_descript($mysqli);
?>
    <div id="gallery" class="col-1 ind border-indent pr-menu">
        <div class="pink-border">
            <h3 class="pink center">Примерное меню одного дня</h3>
            <div class="col-1">
                <div class="col-3">
                    <strong>Утро</strong>
                    <b>Завтрак</b>
                    <p>Каша из булгура с грушевым соте и корицей.</p>
                    <p>Фруктовый салат.</p>
                    <b>Второй завтрак</b>
                    <p>Омлет с брынзой и зеленью.</p>
                </div>
                <div class="col-2-3">
                    <div class="col-3">
                        <div class="wrap">
                            <a href="#" title="Каша из булгура с грушевым соте и корицей" data-sort="1">
                                <img src="/main/image/programs/pr-menu/prev/1.jpg" alt="Каша из булгура с грушевым соте и корицей">
                                <span><em></em></span>
                            </a>
                        </div>
                    </div>
                    <div class="col-3">
                        <div class="wrap">
                            <a href="#" title="Фруктовый салат" data-sort="2">
                                <img src="/main/image/programs/pr-menu/prev/2.jpg" alt="Фруктовый салат">
                                <span><em></em></span>
                            </a>
                        </div>
                    </div>
                    <div class="col-3">
                        <div class="wrap">
                            <a href="#" title="Омлет с брынзой и зеленью" data-sort="3">
                                <img src="/main/image/programs/pr-menu/prev/3.jpg" alt="Омлет с брынзой и зеленью">
                                <span><em></em></span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-1">
                <div class="col-3">
                    <strong>День</strong>
                    <b>Обед</b>
                    <p>Крем-суп из тыквы.</p>
                    <p>Сибас на пару с диким рисом и брокколи.</p>
                    <b>Полдник</b>
                    <p>Творожное смузи с клубникой и запеченной гранолой.</p>
                </div>
                <div class="col-2-3">
                    <div class="col-3">
                        <div class="wrap">
                            <a href="#" title="Крем-суп из тыквы" data-sort="4">
                                <img src="/main/image/programs/pr-menu/prev/4.jpg" alt="Крем-суп из тыквы">
                                <span><em></em></span>
                            </a>
                        </div>
                    </div>
                    <div class="col-3">
                        <div class="wrap">
                            <a href="#" title="Сибас на пару с диким рисом и брокколи" data-sort="5">
                                <img src="/main/image/programs/pr-menu/prev/5.jpg" alt="Сибас на пару с диким рисом и брокколи">
                                <span><em></em></span>
                            </a>
                        </div>
                    </div>
                    <div class="col-3">
                        <div class="wrap">
                            <a href="#" title="Творожное смузи с клубникой и запеченной гранолой" data-sort="6">
                                <img src="/main/image/programs/pr-menu/prev/6.jpg" alt="Творожное смузи с клубникой и запеченной гранолой">
                                <span><em></em></span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-1">
                <div class="col-3">
                    <strong>Вечер</strong>
                    <b>Ужин</b>
                    <p>Гаспачо с вялеными томатами и рукколой.</p>
                    <p>Фреш-бургер на зеленом салате.</p>
                </div>
                <div class="col-2-3">
                    <div class="col-3">
                        <div class="wrap">
                            <a href="#" title="Гаспачо с вялеными томатами и рукколой" data-sort="7">
                                <img src="/main/image/programs/pr-menu/prev/7.jpg" alt="Гаспачо с вялеными томатами и рукколой">
                                <span><em></em></span>
                            </a>
                        </div>
                    </div>
                    <div class="col-3">
                        <div class="wrap">
                            <a href="#" title="Фреш-бургер на зеленом салате" data-sort="8">
                                <img src="/main/image/programs/pr-menu/prev/8.jpg" alt="Фреш-бургер на зеленом салате">
                                <span><em></em></span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php
    comment_pr($mysqli);
    include $root.'/main/block/checkout_full.php';
    include $root.'/main/block/partners.php';
    echo '</div>';
    include $root.'/main/block/footer.php';
    include $root.'/main/block/popup_checkout_cart.php';
?>