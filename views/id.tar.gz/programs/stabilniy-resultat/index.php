<?php
    $root = $_SERVER['DOCUMENT_ROOT'];
    $title = 'Программа питания "Стабильный результат" - Ideal Day';
    include $root.'/programs/programs.php';
?>
