<?php
    $root = $_SERVER['DOCUMENT_ROOT'];
    require $root.'/main/lib/ideal_db.php';
    require $root.'/main/lib/func_lib.php';
    $url = 'white-menu';
    $field = 'headline,title,description,keywords,imgname,other,content';
    $table = 'mainday';
    include $root.'/main/block/header.php';
?>
<div class="content white-menu one-pr">
    <div class="crumbs">
        <ul>
            <li><a href="/">Главная</a></li>
            <li><p>
                <?php echo $myrow['headline']; ?>
            </p></li>
        </ul>
    </div>
    <div class="green-bg"><h1><?php echo $myrow['headline']; ?></h1></div>
    <div class="main-img">
        <img src="/main/image/white-menu/<?php echo $myrow['imgname']; ?>" alt="">
    </div>
    <div class="kсal min-marg two-pr">
        <div class="col-6 ind"><span>1300 <small>ккал/день</small></span><b>3 <small>дня</small> - 5900 <small>руб.</small></b></div>
        <div class="col-6 ind"><span>1700 <small>ккал/день</small></span><b>3 <small>дня</small> - 7900 <small>руб.</small></b></div>
    </div>
    <div id="prinfo-2" class="col-1 border-indent program-info active">
        <div class="green-border">
            <h3><?php echo $myrow['headline']; ?></h3>
            <b><span><?php echo $myrow['other']; ?></span></b>
            <?php echo $myrow['content']; ?>
        </div>
    </div>
<?php
    include $root.'/main/block/checkout_full.php';
    include $root.'/main/block/popup_checkout_white.php';
    include $root.'/main/block/partners.php';
    echo '</div>';
    include $root.'/main/block/footer.php';
?>