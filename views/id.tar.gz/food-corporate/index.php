<?php
    $root = $_SERVER['DOCUMENT_ROOT'];
    require $root.'/main/lib/ideal_db.php';
    require $root.'/main/lib/func_lib.php';
    $field = 'title,description,keywords,headline';
    $table = 'mainday';
    $url = "food-corporate";
    include $root.'/main/block/header.php';
?>
<div class="content one-pr food-corp">
    <div class="crumbs">
        <ul>
            <li><a href="/">Главная</a></li>
            <li><p><?php echo $myrow['headline']; ?></p></li>
        </ul>
    </div>
<?php
    five_plus($mysqli);
    comment_corp($mysqli);
    include $root.'/main/block/checkout_full.php';
    include $root.'/main/block/partners.php';
    echo '</div>';
    include $root.'/main/block/footer.php';
    include $root.'/main/block/popup_checkout_corp.php';
?>