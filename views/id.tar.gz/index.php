<?php
    $root = $_SERVER['DOCUMENT_ROOT'];
    require $root.'/main/lib/ideal_db.php';
    require $root.'/main/lib/func_lib.php';
    $url = 'index';
    $field = '`title`,`description`,`keywords`,`headline`,`content`,`fbtitle`,`fbdescription`,`fbimage`';
    $table = '`mainday`';
    include $root.'/main/block/header.php';
?>
<div class="main-img">
    <img src="/main/image/index/1.jpg" alt="Ideal Day">
    <div class="green-bg">
        <h1><?php echo $myrow['headline']; ?></h1>
        <p><?php echo $myrow['content']; ?></p>
    </div>
</div>
<div class="content">
    <div class="col-1 border-indent">
        <div class="green-border photo">
            <img src="/main/image/index/2.jpg" alt="Анна Козырева">
            <h3 class="pink">Анна Козырева, создательница проекта "IDEAL DAY"</h3>
            <p><strong>Ideal Day</strong> - это система полноценного здорового питания, которая предполагает что:<br>
                - пища должна поступать регулярно (дробно);<br>
                - пища должна быть натуральной, сбалансированной и разнообразной.<br>
                Мы - личный повар, фермерский рынок и эксперт по здоровому питанию в одном лице.<br>
                Благодаря питанию <strong>IDEAL DAY</strong>, ваш организм вырабатывает правильные привычки!<br>
                <strong>Ideal Day</strong> - это отличное самочувствие и стройная фигура без стресса и ограничений!</p>
        </div>
    </div>




    <div class="min-marg checkout-block">
        <div class="col-2 ind border-indent">
            <div class="pink-border">
                <h2 class="pink center">Оставьте заявку</h2>
                <p>Начните отвечать на вопросы диетолога прямо в этом блоке – заполните поля "Рост", "Вес" и "Возраст". Эту информацию мы передадим известному сертифицированнному специалисту по питанию, доценту РУДН, чтобы рассчитать нужное вам количество калорий и подобрать меню. Затем, в личном разговоре мы составим индивидуальное меню, исходя из ваших вкусовых предпочтений анамнеза и стиля жизни.</p>
                <form method="post" action="" onsubmit ="yaCounter31001171.reachGoal('send-form'); return true;"  id="quest">
                    <span>
                        <input type="text" name="age" id="age-quest" placeholder="Ваш возраст">
                        <input type="text" name="growth" id="growth-quest" placeholder="Ваш рост">
                    </span>
                    <span>
                        <input type="text" name="weight" id="weight-quest" placeholder="Ваш вес">
                        <input type="text" name="phone" id="phone-quest" placeholder="Ваш номер телефона">
                    </span>
                    <input type="submit" id="submit" value="Отправить">
                </form>
            </div>
        </div>
        <div class="col-2 ind border-indent center buttons">
            <a href="#" id="checkout" onclick="yaCounter31001171.reachGoal('open-form'); return true;"  class="bg-pink" rel="nofollow"><b>Оформить заказ</b><span>Выберите подходящую программу и закажите ее прямо сейчас</span></a>
            <p><b>+7 999 985 85 85</b><span>Заказы принимаются по телефону</span></p>
        </div>
    </div>
    <div class="col-1 border-indent">
        <div class="green-border photo">
            <img src="/main/image/index/3.jpg" alt="Анна Козырева">
            <h3>Алена Макеева - известный фудблогер:</h3>
            <p>Не могу не написать, так хочется поделиться своим восторгом! Я так вкусно питаюсь: омлет с моцарелой, овощи и индейка гриль, крем маскарпоне и ягоды…мммм… что вы со мной делаете?! Даже ребенок стал проявлять интерес к еде. Как фуд-блоггер я поняла, что не тому училась у людей :)))) Всего третий день, а такая легкость и энергичность, я поражена! Продолжаю эксперимент. И посмотрите как все вкусно на фото! И сроки, сроки!! И да, я начала есть странные для себя продукты и, оказывается, это вкусно; я так рада, что начала менять свои пищевые привычки именно с Ideal day, оказалась, это легко.</p>
        </div>
    </div>
    <div class="col-1 title-block">
        <h2>Лента новостей</h2>
    </div>
    <div class="min-marg index-news">
        <?php
            index_news($mysqli);
        ?>
    </div>
    <?php include $root.'/main/block/partners.php'; ?>
</div>
<?php
    include $root.'/main/block/footer.php';
    include $root.'/main/block/popup_checkout_full.php';
?>