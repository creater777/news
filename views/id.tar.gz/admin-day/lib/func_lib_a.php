<?php
  function other_order($mysqli){
    // $sql = "SELECT * FROM ordersday WHERE status='0' or status='1' ORDER BY id DESC LIMIT 5";
    $sql = "SELECT * FROM `ordersday` WHERE `status`='0' or `status`='1' ORDER BY `id` DESC";
    $res = $mysqli->query($sql) or die('Connect Error (' . $mysqli->connect_errno . ') ' . $mysqli->connect_error);
    while($result = $res->fetch_assoc()){
      echo '<tr><td id="number-order">'.$result['id'].'</td><td id="name"><a href="#" class="link-name" id="edit-'.$result['id'].'">'.$result['name'].'</a></td><td id="email">'.$result['email'].'</td><td id="phone">'.$result['phone'].'</td><td id="program">'.$result['program'].'</td><td id="numday">'.$result['numday'].'</td><td id="calltime">'.$result['calltime'].'</td><td id="age">'.$result['age'].'</td><td id="growth">'.$result['growth'].'</td><td id="weight">'.$result['weight'].'</td><td id="desiredweight">'.$result['desiredweight'].'</td><td id="city">'.$result['city'].'</td><td id="date">'.$result['date'].'</td><td id="action"><a href="#" class="edit" id="edit-'.$result['id'].'">Редакт.</a><a href="#" class="delete" id="del-'.$result['id'].'">Удалить</a></td><td class="status">'.$result['status'].'</td></tr>';
    }
  };

  function delete_list($id_del,$mysqli){
    $sql = "UPDATE `ordersday` SET status='3' WHERE id='$id_del'";
    $res = $mysqli->query($sql) or die('Connect Error (' . $mysqli->connect_errno . ') ' . $mysqli->connect_error);
  };

  function new_order($id_del,$mysqli){
    $sql = "UPDATE ordersday SET status='1' WHERE id='$id_del'";
    $res = $mysqli->query($sql) or die('Connect Error (' . $mysqli->connect_errno . ') ' . $mysqli->connect_error);
  };
?>