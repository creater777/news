<?php
    require '../main/lib/ideal_db.php';
    require '../main/lib/func_lib.php';
    require 'lib/func_lib_a.php';

       session_start();
       
       if (!isset($_SESSION['login']))
       {
            header("Location: http://".$_SERVER['HTTP_HOST']."/admin-day/exit.php");           
       }
       $name = $_SESSION['login'];
       $pass = $_SESSION['pass'];
       $sql = "SELECT name,pass FROM usersday WHERE name='$name' and pass='$pass'";
        $res = $mysqli->query($sql) or die('Connect Error (' . $mysqli->connect_errno . ') ' . $mysqli->connect_error);
        $result = $res->fetch_assoc();

      
    unset($_SESSION['error_auth']);
        if ($name === $result['name'] and $pass === $result['pass']) {
            $_SESSION['login'] = $name;
            $_SESSION['pass'] = $pass;
            $_SESSION['good'] = true;
        } else {
            $_SESSION['error_auth'] = 1;
            $_SESSION['good'] = false;
            unset($_SESSION['name'], $_SESSION['pass']);
            header("Location: http://".$_SERVER['HTTP_HOST']."/admin-day/exit.php");            
        }
    

    
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Ideal Day - Административный раздел</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="css/style.css">
    <script src="/main/js/jquery-2.1.1.min.js"></script>
    <script src="js/main.js"></script>
</head>
<body>
    <div class="sidebar">
        <header>
            <a href="/" title="Главная IDEAL DAY"><img src="/main/img/logo.png" alt="Ideal Day"></a>
        </header>
        <ul>
            <li>
                <a href="#">Заказы Online<span>></span></a>
                <ul>
                    <li><a href="#">Новые</a></li>
                    <li><a href="#">Все</a></li>
                    <li><a href="#">Москва</a></li>
                    <li><a href="#">Тула</a></li>
                    <li><a href="#">Корзина</a></li>
                </ul>
            </li>
        </ul>
    </div>
    <div class="content">
        <div class="main">
            <header>
                <div class="left">
                    <div class="nav active">
                        <a href="#">
                            <span></span>
                            <span></span>
                            <span></span>
                        </a>
                    </div>
                    <div class="notice">
                        <a href="#" class="header-orders"><span><b>2</b></span></a>
                    </div>
                </div>
                <div class="right">
                    <a href="exit.php" class="log-out">Выход</a>
                </div>
            </header>
            <h1>Заказы Online</h1>
            <table cellpadding="0" cellspacing="0" id="order">
                <tr>
                    <th id="number-order">Заказ №</th>
                    <th id="name">Имя</th>
                    <th id="email">Email</th>
                    <th id="phone">Телефон</th>
                    <th id="program">Программа</th>
                    <th id="numday">Количество дней</th>
                    <th id="calltime">Удобное время звонка</th>
                    <th id="age">Возраст</th>
                    <th id="growth">Рост</th>
                    <th id="weight">Вес</th>
                    <th id="desiredweight">Желаемый вес</th>
                    <th id="city">Регион</th>
                    <th id="date">Дата подачи заявки</th>
                    <th id="action">Действия</th>
                </tr>
                <?php other_order($mysqli); ?>
            </table>
            <div class="table-nav">
                <p>Показаны с <b>1</b> по <strong>10</strong> из <span>57</span> записей</p>
                <div class="pager">
                    <div class="drop">
                        <a href="#" data-list="10">
                            <span>10</span><b><em>></em></b></a>
                        <div class="list">
                            <a href="#" data-list="10">10</a>
                            <a href="#" data-list="20">20</a>
                            <a href="#" data-list="50">50</a>
                            <a href="#" data-list="100">100</a>
                            <a href="#" data-list="all">Все</a>
                        </div>
                    </div>
                    <ul>
                        <li><a class="prev" href="#"><</a></li>
                        <li><a href="#">1</a></li>
                        <li><a href="#">2</a></li>
                        <li><a href="#">3</a></li>
                        <li><a href="#">4</a></li>
                        <li><a class="separator" href="#">...</a></li>
                        <li><a href="#">17</a></li>
                        <li><a href="#">18</a></li>
                        <li><a class="next" href="">></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</body>
</html>