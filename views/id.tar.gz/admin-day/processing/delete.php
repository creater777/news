<?php
    require '../../main/lib/ideal_db.php';
    require '../lib/func_lib_a.php';
    
    if ($_POST['id']) {
        $id_del = $_POST['id'];
        delete_list($id_del,$mysqli);
        echo '1';
    }else{
        echo '2';
    }
?>