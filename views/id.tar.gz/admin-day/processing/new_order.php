<?php
    require '../../main/lib/ideal_db.php';
    require '../lib/func_lib_a.php';
    
    if ($_POST['id']) {
        $id_new = $_POST['id'];
        new_order($id_new,$mysqli);
        echo '1';
    }else{
        echo '2';
    }
?>