$(document).ready(function(){
    function sidebarHeight(){
        var contentHeight = $('.content').height();
        var windowHeight = $(window).height();
        var sidebarMenu = $('.sidebar');
        if(contentHeight >= windowHeight){
            sidebarMenu.css({'minHeight':contentHeight+'px'});
        }else{
            sidebarMenu.css({'minHeight':windowHeight+'px'});
        };
    };
    sidebarHeight();

    $('.sidebar').find('ul').find('li').find('a').click(function(){
        if($(this).hasClass('active')){
            $(this).removeClass('active').parent().find('ul').slideUp(300);
        }else{
            $(this).addClass('active').parent().find('ul').slideDown(300);
        }
        return false;
    });

    function showSidebar(){
        $('header .nav').click(function(){
            if($(this).hasClass('active')){
                $(this).removeClass('active');
                $('.sidebar').css({'marginLeft':'-300px'});
                $('.content').css({'width':'100%'});
            }else{
                $(this).addClass('active');
                $('.sidebar').css({'marginLeft':'0px'});
                $('.content').removeAttr('style');
            };
            return false;
        })
    };
    showSidebar();

    function deleteOrder(string){
        string.fadeOut(500);
        setInterval(function(){
            string.remove();
        },600);
    };
    function deleteError(){
        throw 'Error to remove the line';
    };
    function newError(){
        throw 'Error to status "NEW" the line';
    };

    $('.delete').click(function(){
        var idAttr = $(this).attr('id').replace(/[a-z\-]/g, "");
        var tr = $(this).parent().parent();
        $.ajax({
            type:'POST',
            url:'processing/delete.php',
            data:'id='+idAttr,
            success:function(html){
                if(html == 1){
                    deleteOrder(tr);
                }else{
                    deleteError();
                }
            }
        });
        return false;
    });

    $('.status:contains("0")').parent().find('.link-name').addClass('active').append('<span>Новый</span>');

    $('.edit,.link-name').click(function(){
        var idAttr = $(this).attr('id').replace(/[a-z\-]/g, "");
        var link = $(this).parent().parent().find('td').find('.link-name');
        link.find('span').remove();
        $.ajax({
            type:'POST',
            url:'processing/new_order.php',
            data:'id='+idAttr,
            success:function(html){
                if(html == 1){
                    link.find('span').fadeOut(200);
                    setInterval(function(){
                        link.removeClass('active');
                    },400);
                }else{
                    deleteError();
                }
            }
        });
        return false;
    });

    var link = $('.link-name,.edit');
    var popUp = '<div class="main-pop-up"><div class="bg-pop-up"></div><div class="pop-up border-indent"><header><h2>Заказ №</h2><span class="close">×</span></header><form method="post" action="" id="order"><section><p><label for="name-order">Имя:</label><input type="text" name="name" id="name-order" value=""></p><p><label for="email-order">Email:</label><input type="email" name="email" id="email-order" value=""></p><p><label for="phone-order">Телефон:</label><input type="text" name="phone" id="phone-order" value=""></p><p><label for="program-order">Программа:</label><select name="program" id="program-order"><option value="Extreme Lady">Extreme Lady</option><option value="Extreme Gentleman">Extreme Gentleman</option><option value="Comfort Lady">Comfort Lady</option><option value="Comfort Gentleman">Comfort Gentleman</option><option value="Normal Lady">Normal Lady</option><option value="Normal Gentleman">Normal Gentleman</option><option value="Fitness Lady">Fitness Lady</option><option value="Fitness Gentleman">Fitness Gentleman</option><option value="Vegan Lady">Vegan Lady</option><option value="Vegan Gentleman">Vegan Gentleman</option></select></p><p><label for="numday-order">Количество дней:</label><select name="numday" id="numday-order"><option value="1">1</option><option value="10">10</option><option value="21">21</option><option value="30">30</option></select></p><p><label for="time-order">Время звонка:</label><select name="time" id="time-order"><option value="09:00–12:00">09:00–12:00</option><option value="12:00–15:00">12:00–15:00</option><option value="15:00–18:00">15:00–18:00</option><option value="18:00–21:00">18:00–21:00</option></select></p><p><label for="age-order">Возраст:</label><input type="text" name="age" id="age-order" value=""></p><p><label for="growth-order">Рост:</label><input type="text" name="growth" id="growth-order" value=""></p><p><label for="weight-order">Вес:</label><input type="text" name="weight" id="weight-order" value=""></p><p><label for="desired-weight">Желаемый вес:</label><input type="text" name="desired_weight" id="desired-weight" value=""></p><p>Регион: <b></b></p><p>Дата заказа: <b></b></p><p><label for="delete">Удалить:</label><input type="checkbox" id="delete"></p></section><footer><input type="submit" id="save" class="btn-green" value="Сохранить"><input type="submit" id="apply" class="btn-ind" value="Применить"><input type="submit" id="cancel" value="Отмена"></footer></form></div></div>';

    function popUpNew (link,popup) {
        link.click(function(){
            $('.content').append(popup);
            function popupPos(){
                var windowWidth = $(window).width();
                var windowHeight = $(window).height();
                var popUpClass = $('.main-pop-up .pop-up');
                var popUpWidth = popUpClass.innerWidth();
                var popUpHeight = popUpClass.innerHeight();
                var popUpLeftPos = (windowWidth - popUpWidth) / 2;
                var popUpTopPos = (windowHeight - popUpHeight) / 2;
                popUpClass.css({'left':popUpLeftPos+'px','top':popUpTopPos+'px'});
            };
            popupPos();
            $(window).resize(function(){popupPos();});
            $('.main-pop-up .bg-pop-up, .main-pop-up span, .main-pop-up #cancel').click(function(){
                $('.main-pop-up').remove();
                return false;
            });
            var idOrder = $(this).parent().parent().find('#number-order').text();
            $('.main-pop-up h2').append(idOrder);

            var nameOrder = $(this).parent().parent().find('#name').find('a').text();
            $('.main-pop-up #name-order').val(nameOrder);
            var emailOrder = $(this).parent().parent().find('#email').text();
            $('.main-pop-up #email-order').val(emailOrder);
            var phoneOrder = $(this).parent().parent().find('#phone').text();
            $('.main-pop-up #phone-order').val(phoneOrder);

            var progOrder = $(this).parent().parent().find('#program').text();
            $('.main-pop-up #program-order option:contains('+progOrder+')').attr('selected','selected');


            var dayOrder = $(this).parent().parent().find('#numday').text();
            var dayOrderFormEl = $('.main-pop-up #numday-order option:contains('+dayOrder+')');
            var dayOrderForm = dayOrderFormEl.text();
            if(dayOrder === dayOrderForm){
                dayOrderFormEl.attr('selected','selected');
            };


            var timeOrder = $(this).parent().parent().find('#calltime').text();
            $('.main-pop-up #time-order option:contains('+timeOrder+')').attr('selected','selected');


            var ageOrder = $(this).parent().parent().find('#age').text();
            $('.main-pop-up #age-order').val(ageOrder);
            var growthOrder = $(this).parent().parent().find('#growth').text();
            $('.main-pop-up #growth-order').val(growthOrder);
            var weightOrder = $(this).parent().parent().find('#weight').text();
            $('.main-pop-up #weight-order').val(weightOrder);
            var desiredWeight = $(this).parent().parent().find('#desiredweight').text();
            $('.main-pop-up #desired-weight').val(desiredWeight);

            var regOrder = $(this).parent().parent().find('#city').text();
            $('.main-pop-up p:contains("Регион") b').text(regOrder);
            var dateOrder = $(this).parent().parent().find('#date').text();
            $('.main-pop-up p:contains("Дата заказа") b').text(dateOrder);


        });
    };
    popUpNew(link,popUp);

    $(window).resize(function(){
        sidebarHeight();
    });
});