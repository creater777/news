<?php
    session_start();
    unset($_SESSION['login']);
    unset($_SESSION['pass']);
    header("Location: http://".$_SERVER['HTTP_HOST']."/admin-day/auth.php");
?>