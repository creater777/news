<?php
    require '../main/lib/ideal_db.php';
    session_start();
    $name = mysqli_real_escape_string($mysqli,$_POST['username']);
    $pass = hash(md5,hash(md5,mysqli_real_escape_string($mysqli,$_POST['password'])));

    if (!is_array($_SESSION['error_auth']) and is_array($_SESSION['name']) and is_array($_SESSION['pass'])) {
    header("Location: http://".$_SERVER['HTTP_HOST']."/admin-day/");
    }

    if($_POST){
        $sql = "SELECT name,pass FROM usersday WHERE name='$name' and pass='$pass'";
        $res = $mysqli->query($sql) or die('Connect Error (' . $mysqli->connect_errno . ') ' . $mysqli->connect_error);
        $result = $res->fetch_assoc();

        unset($_SESSION['error_auth']);
        if ($name === $result['name'] and $pass === $result['pass']) {
            $_SESSION['login'] = $name;
            $_SESSION['pass'] = $pass;
            $_SESSION['good'] = true;
            header("Location: http://".$_SERVER['HTTP_HOST']."/admin-day/");
        } else {
            $_SESSION['error_auth'] = 1;
            $_SESSION['good'] = false;
            unset($_SESSION['name'], $_SESSION['pass']);
            
        }
    }
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Вход в Ideal Day</title>
    <link rel="stylesheet" href="css/login.css">
    <script src="js/login.js"></script>
    <?php include '../main/block/favicon.php'; ?>
</head>
<body>
    <header><a href="/"><img src="/main/img/logo.png" alt="Ideal Day"></a></header>
    <div class="login">
        <form method="post" action="">
            <p>
                <input type="text" name="username" placeholder="Логин" autocomplete="off">
                <span class="user"></span>
            </p>
            <p>
                <input type="password" name="password" placeholder="Пароль" autocomplete="off">
                <span class="pass"></span>
            </p>
            <p>
                <input type="submit" value="Войти">
            </p>
        </form>
        <p><b></b><a href="/">Перейти к сайту</a></p>
    </div>
    <footer>ideal-day.com &copy; <?php echo date('Y'); ?>. <a href="https://atrmantis.com">ARTMANTIS</a></footer>
</body>
</html>