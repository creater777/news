<?php
    $root = $_SERVER['DOCUMENT_ROOT'];
    require $root.'/main/lib/ideal_db.php';
    require $root.'/main/lib/func_lib.php';
    $url = 'master-class';
    $field = 'headline,title,description,keywords,imgname,other,content';
    $table = 'mainday';
    include $root.'/main/block/header.php';
?>
<div class="content white-menu one-pr">
    <div class="crumbs">
        <ul>
            <li><a href="/">Главная</a></li>
            <li><p>
                <?php echo $myrow['headline']; ?>
            </p></li>
        </ul>
    </div>
    <div class="green-bg"><h1><?php echo $myrow['headline']; ?></h1></div>
    <div class="main-img">
        <img src="/main/image/master-class/<?php echo $myrow['imgname']; ?>" alt="">
    </div>
    
    <div id="prinfo-2" class="col-1 border-indent program-info active">
        <div class="green-border">
            <h3><?php echo $myrow['headline']; ?></h3>
            <b><span><?php echo $myrow['other']; ?></span></b>
            <?php echo $myrow['content']; ?>
        </div>
        <div style="position: relative;">
	        <div style="float:left; position:relative; left:50%;">
	        	<div style="float:left; position:relative; left:-50%;">
		            <img src="/main/image/master-class/image1.JPG" width="190" height="270" class="img-margin-top">
		            <img src="/main/image/master-class/image2.JPG" width="350" height="270" class="img-margin-top">
		            <img src="/main/image/master-class/image3.JPG" width="190" height="270" class="img-margin-top">
		            <img src="/main/image/master-class/image4.JPG" width="350" height="270" class="img-margin-top">
		            <img src="/main/image/master-class/image5.JPG" width="190" height="270" class="img-margin-top">
		            <img src="/main/image/master-class/image6.JPG" width="350" height="270" class="img-margin-top">
		        </div>
	        </div>
        </div>
    </div>
    <?php 
        index_prev_master_class($mysqli)
    ?>
    <div class="col-1 border-indent program-info active">
        <div class="green-border">
            <h3>Выходные мы проводим с пользой для здоровья и настроения!</h3> 
            <h3>Присоединяйтесь к нам!</h3>
            <p>
                Мастер класс это отличная идея интересно провести свой день рождение!<br/>
                Приходите к нам с друзьями, родными и близкими! <br/>
                <br/>
                Предварительная запись обязательна<br/>тел.: +7 999 985 85 85
            </p>
        </div>
    </div>

    <?php
        include $root.'/main/block/checkout_full.php';
        include $root.'/main/block/partners.php';
    ?>
</div>
<?php
    include $root.'/main/block/footer.php';
    include $root.'/main/block/popup_checkout_full.php';
?>