<?php
    $root = $_SERVER['DOCUMENT_ROOT'];
    require $root.'/main/lib/ideal_db.php';
    require $root.'/main/lib/func_lib.php';
    $url = 'master-class';
    $field = 'headline,title,description,keywords,imgname,other,content';
    $table = 'mainday';
    include $root.'/main/block/header.php';
?>
<div class="content white-menu one-pr">
    <div class="crumbs">
        <ul>
            <li><a href="/">Главная</a></li>
            <li><p>
                <?php echo $myrow['headline']; ?>
            </p></li>
        </ul>
    </div>
    <div class="green-bg"><h1><?php echo $myrow['headline']; ?></h1></div>
    <div class="main-img">
        <img src="/main/image/master-class/<?php echo $myrow['imgname']; ?>" alt="">
    </div>
    
    <div id="prinfo-2" class="col-1 border-indent program-info active">
        <div class="green-border">
            <h3>Мастер класс ко дню всех влюблённых</h3>
        </div>
    </div>
    
    <div class="col-1 border-indent program-info active">
        <div class="green-border">
            <?php 
                index_master_class($mysqli, 3);
            ?>
                <img src="/main/image/master-class/love/1.jpg" width="320" height="250" alt="" class="img-margin-top">
                <img src="/main/image/master-class/love/2.jpg" width="320" height="250" alt="" class="img-margin-top">
                <img src="/main/image/master-class/love/3.jpg" width="320" height="250" alt="" class="img-margin-top">
        </div>
    </div>


    <div>
        
    </div>
    

    <?php
        include $root.'/main/block/checkout_full.php';
        include $root.'/main/block/partners.php';
    ?>
</div>
<?php
    include $root.'/main/block/footer.php';
    include $root.'/main/block/popup_checkout_full.php';
?>