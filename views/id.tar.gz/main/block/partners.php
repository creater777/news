<div class="partners">
    <div class="col-1">
        <div class="col-5">
            <a href="http://www.spa-algotherm.ru/" title="Меди СПА центр Spa by Algotherm" target="_blank" rel="nofollow"><img src="/main/image/partner/spa-algotherm.png" alt="Меди СПА центр Spa by Algotherm"></a>
        </div>
        <div class="col-5">
            <a href="http://www.lezard.ru/" title="УЦМС «Лечение за рубежом» (ЛЕЗАР)" target="_blank" rel="nofollow"><img src="/main/image/partner/lazar.png" alt="УЦМС «Лечение за рубежом» (ЛЕЗАР)"></a>
        </div>
        <div class="col-5">
            <a href="http://youtu.be/GxVc2SuBOaY" title="Laser Lounge Clinic" target="_blank" rel="nofollow"><img src="/main/image/partner/llc.png" alt="Ideal Day"></a>
        </div>
        <div class="col-5">
            <a href="http://youlikedance.ru" title="Школа танцев Ягодницыной Ольги" target="_blank" rel="nofollow"><img src="/main/image/partner/dance-school.png" alt="ArtMantis"></a>
        </div>
        <div class="col-5">
            <a href="http://kykolki.com/" title='Имидж-студия "Куклы"' target="_blank" rel="nofollow"><img src="/main/image/partner/kykolki.jpg" alt='Имидж-студия "Куклы"'></a>
        </div>
        <div class="col-5">
            <a href="http://www.winebutik.net" title='КАУДАЛЬ винный дом' target="_blank" rel="nofollow"><img src="/main/image/partner/winebutik.png" alt='КАУДАЛЬ винный дом'></a>
        </div>
        <div class="col-5">
            <a href="http://restotube.ru/" title='RestoTube - ресторанный видео гид' target="_blank" rel="nofollow"><img src="/main/image/partner/restotube.png" alt='RestoTube - ресторанный видео гид'></a>
        </div>
        <div class="col-5">
            <a href="http://www.tseleevo.ru/" title="Горнолыжный Клуб Целеево" target="_blank" rel="nofollow"><img src="/main/image/partner/zeleevo.png" alt="Горнолыжный Клуб Целеево"></a>
        </div>
        <div class="col-5">
            <a href="http://www.palchiki.com/" title="Профессиональный маникюр и педикюр" target="_blank" rel="nofollow"><img src="/main/image/partner/palchiki.png" alt="Профессиональный маникюр и педикюр"></a>
        </div>
        <div class="col-5">
            <a href="http://www.gagarinmedia.ru/" title="Корпоративное телевидение" target="_blank" rel="nofollow"><img src="/main/image/partner/gm.png" alt="Корпоративное телевидение"></a>
        </div>
    </div>
</div>