<div class="checkout-block">
    <div class="col-1 border-indent center buttons">
        <a href="#" id="checkout" onclick="yaCounter31001171.reachGoal('open-form'); return true;"  class="bg-pink" rel="nofollow"><b>Оформить заказ</b><span>Выберите подходящую программу и закажите ее прямо сейчас</span></a>
        <p><b>+7 999 985 85 85</b><span>Заказы принимаются по телефону</span></p>
    </div>
</div>