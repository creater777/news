<?php
    $myrow = unloading_main($mysqli,$field,$table,$url);
    $myheadline = $myrow['headline'];
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title><?php echo $myrow['title']; ?></title>
    <meta name="description" content="<?php echo $myrow['description']; ?>">
    <meta name="keywords" content="<?php echo $myrow['keywords']; ?>">
    <meta property="og:title" content="<?php echo $myrow['fbtitle']; ?>"/>
    <meta property="og:description" content="<?php echo $myrow['fbdescription']; ?>"/>
    <meta property="og:image" content="/main/image/soc-preview/<?php echo $myrow['fbimage']; ?>"/>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="/main/css/style.css">
    <script src="/main/js/jquery-2.1.1.min.js"></script>
    <script src="/main/js/jquery-ui.min.js"></script>
    <script src="/main/js/main.js"></script>
    <script language=JavaScript>
    <!--
        ///////////////////////////////////
              function clickIE4(){
              if (event.button==2){
              return false;
              }
              }
        function clickNS4(e){
              if (document.layers||document.getElementById&&!document.all){
              if (e.which==2||e.which==3){
              return false;
              }
              }
              }
        if (document.layers){
              document.captureEvents(Event.MOUSEDOWN);
              document.onmousedown=clickNS4;
              }
              else if (document.all&&!document.getElementById){
              document.onmousedown=clickIE4;
              }
        document.oncontextmenu=new Function("return false")
    // -->
    </script>








    <?php include 'favicon.php'; ?>
</head>
<body>
    <div class="left-block">
        <a href="/" class="logo"><img src="/main/img/logo.png" alt="Ideal Day"></a>
        <nav>
            <ul>
                <li>
                    <a href="/company/"><b>О компании</b></a>
                    <ul>
                        <li><a href="/company/o-nas/"><b>О нас</b></a></li>
                        <li><a href="/company/prostyie-pravila-dnya/"><b>Простые правила дня</b></a></li>
                        <li><a href="/company/nasha-comanda/ideal-wellness-couch/"><b>Наша команда</b></a></li>
                    </ul>
                </li>
                <li><a href="/programs/stabilniy-resultat/"><b>Программы питания</b></a></li>
                <li><a href="/food-corporate/"><b>Корпоративное питание</b></a></li>
                <li><a href="/white-menu/"><b>White Menu</b></a></li>
                <li><a href="/news/"><b>Лента новостей</b></a></li>
                <li><a href="/event/"><b>Акции</b></a></li>
                <li><a href="/master-class/"><b>Мастер классы</b></a></li>
                <li><a href="/keytering/"><b>Кейтеринг</b></a></li>
                <li><a href="/contact/"><b>Контакты</b></a></li>
            </ul>
        </nav>
        <div class="left-footer">
            <p>+7 999 985 85 85</p>
            <div class="soc">
                <a class="in" href="https://instagram.com/ideal.day/" target="_blank" rel="nofollow"></a>
                <!-- <a class="tw" href="https://twitter.com/" target="_blank" rel="nofollow"></a> -->
                <a class="fb" href="https://www.facebook.com/pages/Ideal-Day/846500995413544" target="_blank" rel="nofollow"></a>
                <!-- <a class="vk" href="http://vk.com/" target="_blank" rel="nofollow"></a> -->
            </div>
        </div>
    </div>
    <div class="main">
        <header>
            <div class="col-3 nav">
                <a href="#">
                    <span></span>
                    <span></span>
                    <span></span>
                </a>
            </div>
            <div class="col-3 logo">
                <a href="/" class="logo"><img src="/main/img/logo.png" alt="Ideal Day"></a>
            </div>
            <div class="col-3 phone">
                <p>+7 999 985 85 85</p>
            </div>
        </header>