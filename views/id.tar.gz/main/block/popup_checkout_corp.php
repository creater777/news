<div class="main-pop-up">
    <div class="bg-pop-up">
        <div class="bg-close"></div>
        <div class="pop-up border-indent">
            <div class="pink-border">
                <span>&times;</span>
                <h2 class="pink">Заказ программы Ideal Day</h2>
                <p><img src="/main/img/logo.png" alt="Ideal Day"></p>
                <form method="post" action="" onsubmit ="yaCounter31001171.reachGoal('send-form'); return true;"  id="order">
                    <p>
                        <input type="hidden" name="program" id="program" value="<?php echo $myheadline; ?>">
                        <strong><?php echo $myheadline; ?></strong>
                    </p>
                    <p>
                        <input type="text" name="name" id="name" placeholder="Ваше имя и фамилия">
                        <input type="email" name="email" id="email" placeholder="Адрес эл. почты">
                    </p>
                    <p>
                        <input type="text" name="phone" id="phone" placeholder="Ваш номер телефона">
                        <select name="time" id="time">
                            <option disabled="disabled" selected="selected">Время обратного звонка</option>
                            <option value="09:00–12:00">09:00–12:00</option>
                            <option value="12:00–15:00">12:00–15:00</option>
                            <option value="15:00–18:00">15:00–18:00</option>
                            <option value="18:00–21:00">18:00–21:00</option>
                        </select>
                    </p>
                    <p class="form-info">
                        <input type="text" name="growth" id="growth" placeholder="Рост">
                        <input type="text" name="weight" id="weight" placeholder="Вес">
                        <input type="text" name="age" id="age" placeholder="Возраст">
                        <input type="text" name="desired_weight" id="desired-weight" placeholder="Желаемый вес">
                    </p>
                    <div class="slider-ui">
                        <div id="slider">
                            <b class="ui-slider-handle"></b>
                        </div>
                        <div class="slider-text">
                            <p class="nth-0 active">1</p>
                            <p class="nth-10">10</p>
                            <p class="nth-20">21</p>
                            <p class="nth-30">30</p>
                        </div>
                        <input type="hidden" name="num_day" id="num-day" value="10">
                        <strong>Бесплатная доставка</strong>
                        <b class="info">Заказы принимаются от 5 пакетов по одному адресу!</b>
                    </div>
                    <input type="submit" id="submit" value="Отправить">
                    <small></small>
                </form>
            </div>
        </div>
    </div>
</div>