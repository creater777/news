<footer>
            <ul>
                <li><a href="/company/">О компании</a></li>
                <li><a href="/programs/">Программы питания</a></li>
                <li><a href="/food-corporate/">Корпоративное питание</a></li>
                <li><a href="/white-menu/">White Menu</a></li>
                <li><a href="/news/">Лента новостей</a></li>
                <li><a href="/event/">Акции</a></li>
                <li><a href="/contact/">Контакты</a></li>
            </ul>
            <span>+7 999 985 85 85</span>
            <p>&copy; <?php echo date('Y'); ?> Ideal Day</p>
        </footer>
    </div>
    <!-- Yandex.Metrika counter -->
<script type="text/javascript">
    (function (d, w, c) {
        (w[c] = w[c] || []).push(function() {
            try {
                w.yaCounter39085605 = new Ya.Metrika({
                    id:39085605,
                    clickmap:true,
                    trackLinks:true,
                    accurateTrackBounce:true,
                    webvisor:true
                });
            } catch(e) { }
        });

        var n = d.getElementsByTagName("script")[0],
            s = d.createElement("script"),
            f = function () { n.parentNode.insertBefore(s, n); };
        s.type = "text/javascript";
        s.async = true;
        s.src = "https://mc.yandex.ru/metrika/watch.js";

        if (w.opera == "[object Opera]") {
            d.addEventListener("DOMContentLoaded", f, false);
        } else { f(); }
    })(document, window, "yandex_metrika_callbacks");
</script>
<noscript><div><img src="https://mc.yandex.ru/watch/39085605" style="position:absolute; left:-9999px;" alt="" /></div></noscript>
<!-- /Yandex.Metrika counter -->
    <script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-82637542-1', 'auto');
  ga('send', 'pageview');

</script>
</body>
</html>