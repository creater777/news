<?php 
    define("DB_HOST", "localhost");
    define("DB_LOGIN", "a0087749_id");
    define("DB_PASSWORD", "62KRqURr");
    define("DB_NAME", "a0087749_id");

    $mysqli = new mysqli(DB_HOST, DB_LOGIN, DB_PASSWORD, DB_NAME);
        if ($mysqli->connect_error) {
            die($mysqli->connect_error);
        }
    $mysqli->query("SET NAMES 'utf8'");
 ?>