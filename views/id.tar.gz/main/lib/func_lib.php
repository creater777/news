<?php







function unloading_main($mysqli,$field,$table,$url){
    $sql = "SELECT $field FROM $table WHERE page='$url'";
    $result = $mysqli->query($sql) or die('Connect Error (' . $mysqli->connect_errno . ') ' . $mysqli->connect_error);
    $myrow = $result->fetch_assoc();
    return $myrow;
}

function save_order($name,$email,$phone,$program,$num_day,$time,$growth,$weight,$age,$desired_weight,$city,$mysqli){
    $sql = "INSERT INTO ordersday(`name`,`email`,`phone`,`program`,`numday`,`calltime`,`growth`,`weight`,`age`,`desiredweight`,`city`,`status`) VALUES('$name','$email','$phone','$program',$num_day,'$time',$growth,$weight,$age,$desired_weight,'$city',0)";
    $mysqli->query($sql) or die('Connect Error (' . $mysqli->connect_errno . ') ' . $mysqli->connect_error);

};

function landing_one($name,$email,$phone,$program,$time,$city,$mysqli){
    $sql = "INSERT INTO ordersday(`name`,`email`,`phone`,`program`,`numday`,`calltime`,`growth`,`weight`,`age`,`desiredweight`,`city`,`status`) VALUES('$name','$email','$phone','$program',0,'$time',0,0,0,0,'$city',0)";
    $mysqli->query($sql) or die('Connect Error (' . $mysqli->connect_errno . ') ' . $mysqli->connect_error);
};

function save_quest($age,$growth,$weight,$phone,$program,$city,$mysqli){
    $sql = "INSERT INTO ordersday(`name`,`email`,`phone`,`numday`,`calltime`,`age`,`growth`,`weight`,`desiredweight`,`program`,`city`,`status`) VALUES('','','$phone',0,'','$age','$growth','$weight',0,'$program','$city',0)";
    $mysqli->query($sql) or die('Connect Error (' . $mysqli->connect_errno . ') ' . $mysqli->connect_error);
};

function pr_slide($mysqli){
    $sql = "SELECT program_id,titleslide FROM newprograms ORDER BY sort ASC";
    $res = $mysqli->query($sql) or die('Connect Error (' . $mysqli->connect_errno . ') ' . $mysqli->connect_error);
    while($result = $res->fetch_assoc()){
        echo '<li id="slide-'.$result['program_id'].'" class=""><a href="#">'.$result['titleslide'].'</a></li>';
    }
};

function pr_slide_new($mysqli){
    $programs_url_array= array(
        '',
        'vegan-post',
        'stabilniy-resultat',
        'bistry-resultat',
        'fitness-dieta',
        'stroinost-na-vsu-gizn',
        'idealno-individualno',

        );
    $sql = "SELECT program_id,titleslide FROM newprograms ORDER BY sort ASC";
    $res = $mysqli->query($sql) or die('Connect Error (' . $mysqli->connect_errno . ') ' . $mysqli->connect_error);
    while($result = $res->fetch_assoc()){
        echo '<li id="slide-'.$result['program_id'].'" class=""><a href="http://ideal-day.com/programs/'.$programs_url_array[$result['program_id']].'/">'.$result['titleslide'].'</a></li>';
    }
};

function front_slide($mysqli){
    $sql = "SELECT program_id,titleslide FROM newprograms ORDER BY sort ASC";
    $res = $mysqli->query($sql) or die('Connect Error (' . $mysqli->connect_errno . ') ' . $mysqli->connect_error);
    while($result = $res->fetch_assoc()){
        echo '<div id="front-'.$result['program_id'].'" class="front-slide"><a href="#">'.$result['titleslide'].'</a></div>';
    }
};

function pr_descript($mysqli){
    $sql = "SELECT program_id,titleslide,lady,gentleman,description FROM newprograms";
    $res = $mysqli->query($sql) or die('Connect Error (' . $mysqli->connect_errno . ') ' . $mysqli->connect_error);
    while($result = $res->fetch_assoc()){
        echo '<div id="prinfo-'.$result['program_id'].'" class="col-1 border-indent program-info"><div class="green-border"><h3>'.$result['titleslide'].'</h3><b><span>'.$result['lady'].'</span><span class="slash"> / </span><span>'.$result['gentleman'].'</span></b>'.$result['description'].'</div></div>';
    }
};

function inset_our_team_new($mysqli){
    $comanda_url_array= array(
        '',
        'ideal-wellness-couch',
        'ideal-komanda-povarov',
        'ideal-dietolog',

        );
    $sql = "SELECT id,inset FROM insetday WHERE other='company'";
    $res = $mysqli->query($sql) or die('Connect Error (' . $mysqli->connect_errno . ') ' . $mysqli->connect_error);
    $result = $res->fetch_assoc();
    do {
        echo '<a id="inset-'.$result['id'].'" href="http://ideal-day.com/programs/'.$comanda_url_array[$result['id']].'/">'.$result['inset'].'</a>';
    } while ($result = $res->fetch_assoc());
};
function inset_our_team($mysqli){
    $sql = "SELECT id,inset FROM insetday WHERE other='company'";
    $res = $mysqli->query($sql) or die('Connect Error (' . $mysqli->connect_errno . ') ' . $mysqli->connect_error);
    $result = $res->fetch_assoc();
    do {
        echo '<a id="inset-'.$result['id'].'" href="#">'.$result['inset'].'</a>';
    } while ($result = $res->fetch_assoc());
};

function info_our_team($mysqli){
    $sql = "SELECT id,img,title,addtitle,full,other FROM insetday WHERE other='company'";
    $res = $mysqli->query($sql) or die('Connect Error (' . $mysqli->connect_errno . ') ' . $mysqli->connect_error);
    $result = $res->fetch_assoc();
    do {
        echo '<div id="info-'.$result['id'].'" class="green-border photo"><img src="/main/image/'.$result['other'].'/'.$result['img'].'" alt="'.$result['title'].'"><h3 class="pink">'.$result['title'].'<span>'.$result['addtitle'].'</span></h3>'.$result['full'].'</div>';
    } while ($result = $res->fetch_assoc());
};

function about_us($mysqli){
    $sql = "SELECT title,full FROM aboutus ORDER BY sort ASC";
    $res = $mysqli->query($sql) or die('Connect Error (' . $mysqli->connect_errno . ') ' . $mysqli->connect_error);
    $result = $res->fetch_assoc();
    do {
        echo '<div class="col-5"><h3>'.$result['title'].'</h3><p>'.$result['full'].'</p></div>';
    } while ($result = $res->fetch_assoc());
};

function recall($mysqli){
    $sql = "SELECT title,textfull,image FROM idealrecall ORDER BY sort ASC";
    $res = $mysqli->query($sql) or die('Connect Error (' . $mysqli->connect_errno . ') ' . $mysqli->connect_error);
    while ($result = $res->fetch_assoc()){
        echo '<div class="col-1 border-indent comment"><div class="green-border"><div class="circle"><img src="/main/image/company/recall/'.$result['image'].'" alt="'.$result['title'].'"></div><div class="discription"><h3 class="pink">'.$result['title'].'</h3><p>'.$result['textfull'].'</p><a href="#" class="under pink">Подробнее</a></div></div></div>';
    }
};

function comment_corp($mysqli){
    $sql = "SELECT `title`,`textfull`,`image` FROM `idealrecall` WHERE `program_id`=0 ORDER BY `sort` ASC";
    $res = $mysqli->query($sql) or die('Connect Error (' . $mysqli->connect_errno . ') ' . $mysqli->connect_error);
    while ($result = $res->fetch_assoc()){
        echo '<div class="col-1 border-indent comment"><div class="green-border photo"><div class="circle"><img src="/main/image/company/recall/'.$result['image'].'" alt="'.$result['title'].'"></div><div class="discription"><h3 class="pink">'.$result['title'].'</h3><p>'.$result['textfull'].'</p><a href="#" class="under pink">Подробнее</a></div></div></div>';
    }
};

function comment_pr($mysqli){
    $sql = "SELECT `title`,`textfull`,`image`,`program_id` FROM `idealrecall` WHERE `program_id`!=0 ORDER BY `sort` ASC";
    $res = $mysqli->query($sql) or die('Connect Error (' . $mysqli->connect_errno . ') ' . $mysqli->connect_error);
    while ($result = $res->fetch_assoc()){
        echo '<div id="com-'.$result['program_id'].'" class="col-1 border-indent comment none"><div class="green-border photo"><div class="circle"><img src="/main/image/company/recall/'.$result['image'].'" alt="'.$result['title'].'"></div><div class="discription"><h3 class="pink">'.$result['title'].'</h3><p>'.$result['textfull'].'</p><a href="#" class="under pink">Подробнее</a></div></div></div>';
    }
};

function index_news($mysqli){
    $sql = "SELECT headline,page,datenews,previewtext,detailtext FROM newsday ORDER BY datenews DESC LIMIT 3";
    $res = $mysqli->query($sql) or die('Connect Error (' . $mysqli->connect_errno . ') ' . $mysqli->connect_error);
    $result = $res->fetch_assoc();
    do {
        if (empty($result['previewtext'])) {
            $prevtext = $result['detailtext'];
        } else {
            $prevtext = $result['previewtext'];
        }
        echo '<div class="col-3 ind border-indent"><a href="/news/'.$result['page'].'" class="img"><img src="/main/image/news/'.$result['page'].'/index-preview.jpg" alt="'.$result['headline'].'"><b><span>Подробнее</span></b></a><div class="descript"><a href="/news/'.$result['page'].'">'.$result['headline'].'</a><div class="prevtext">'.$prevtext.'</div></div></div>';
    } while ($result = $res->fetch_assoc());
};

function index_prev($mysqli){
    $sql = "SELECT headline,page,datenews,previewtext,detailtext FROM newsday ORDER BY datenews DESC";
    $res = $mysqli->query($sql) or die('Connect Error (' . $mysqli->connect_errno . ') ' . $mysqli->connect_error);
    $result = $res->fetch_assoc();
    do {
        if (empty($result['previewtext'])) {
            $prevtext = $result['detailtext'];
        } else {
            $prevtext = $result['previewtext'];
        }
        echo '<div class="col-1 border-indent"><div class="green-border photo"><a href="/news/'.$result['page'].'" class="img"><img src="/main/image/news/'.$result['page'].'/preview.jpg" alt="'.$result['headline'].'"><b><span>Подробнее</span></b></a><a href="/news/'.$result['page'].'">'.$result['headline'].'</a><div class="prevtext">'.$prevtext.'</div></div></div>';
    } while ($result = $res->fetch_assoc());
};

function index_prev_master_class($mysqli){
    $sql = "SELECT * FROM `masterday` ORDER BY id DESC";
    $res = $mysqli->query($sql) or die('Connect Error (' . $mysqli->connect_errno . ') ' . $mysqli->connect_error);
    $result = $res->fetch_assoc();
    do {
        if (empty($result['container'])) {
            $prevtext = '';
        } else {
            $prevtext = $result['container'];
        }
        echo '
        <div class="col-1 border-indent program-info active">
            <div class="green-border">
                <div class="margin-master">
                    <div class="master-image">
                        <img src="/main/image/master-class/'.$result['page'].'/preview.jpg" class="round">
                    </div>
                    <div class="master-text">
                        <a href="/master-class/'.$result['page'].'"><h2>'.$result['title'].'</h2></a>
                         <p>'.$result['short'].'</p>
                    </div>
                </div>
            </div>
        </div>
        ';
    } while ($result = $res->fetch_assoc());
};

function index_master_class($mysqli, $id){
    $sql = "SELECT * FROM `masterday` WHERE `id` = ".$id;
    $res = $mysqli->query($sql) or die('Connect Error (' . $mysqli->connect_errno . ') ' . $mysqli->connect_error);
    $result = $res->fetch_assoc();
    do {
        if (empty($result['container'])) {
            $prevtext = '';
        } else {
            $prevtext = $result['container'];
        }
        echo '

        <a href="/master-class/'.$result['page'].'">'.$result['title'].'</a>
			  <div class="prevtext" style="height: 150px;">'.$prevtext.'</div>';
    } while ($result = $res->fetch_assoc());
};








function detail_news($mysqli,$url){
    $sql = "SELECT headline,page,detailtext,image FROM newsday WHERE page='$url'";
    $res = $mysqli->query($sql) or die('Connect Error (' . $mysqli->connect_errno . ') ' . $mysqli->connect_error);
    $result = $res->fetch_assoc();
    echo '<div class="photo-gallery"><img src="/main/image/news/'.$result['page'].'/'.$result['image'].'" alt="'.$result['headline'].'"></div><h1 class="pink">'.$result['headline'].'</h1>'.$result['detailtext'];
};

function detail_news_video($mysqli,$url){
    $sql = "SELECT headline,page,detailtext FROM newsday WHERE page='$url'";
    $res = $mysqli->query($sql) or die('Connect Error (' . $mysqli->connect_errno . ') ' . $mysqli->connect_error);
    $result = $res->fetch_assoc();
    echo '<div class="photo-gallery"></div><h1 class="pink">'.$result['headline'].'</h1>'.$result['detailtext'];
};

function rules_day($mysqli){
    $sql = "SELECT title,description FROM rulesday ORDER BY sort ASC";
    $res = $mysqli->query($sql) or die('Connect Error (' . $mysqli->connect_errno . ') ' . $mysqli->connect_error);
    $result = $res->fetch_assoc();
    do {
        echo '<h1 class="pink center">'.$result['title'].'</h1>'.$result['description'];
    } while ($result = $res->fetch_assoc());
};

function company_page($mysqli){
    $sql = "SELECT `url`,`name`,`parent`,`prevtext`,`image` FROM `navday` WHERE `parent`='company' AND `active`=1 ORDER BY `sort` ASC";
    $res = $mysqli->query($sql) or die('Connect Error (' . $mysqli->connect_errno . ') ' . $mysqli->connect_error);
    while($result = $res->fetch_assoc()){
        echo '<div class="col-4 ind border-indent"><a href="/'.$result['parent'].'/'.$result['url'].'/" class="img"><img src="/main/image/'.$result['parent'].'/'.$result['image'].'" alt="'.$result['name'].'?"><b></b><span class="pink-bg-op">'.$result['name'].'</span></a><p>'.$result['prevtext'].'</p></div>';
    }
};

function five_plus($mysqli){
    $sql = "SELECT `name`,`textcorp` FROM `corpfood` WHERE `parent`='top'";
    $res = $mysqli->query($sql) or die('Connect Error (' . $mysqli->connect_errno . ') ' . $mysqli->connect_error);
    $result = $res->fetch_assoc();
    echo '<div class="corp-food"><div class="col-1 center fn"><h1 class="pink">'.$result['name'].'</h1><p>'.$result['textcorp'].'</p></div><div class="kсal min-marg two-pr"><div class="col-6 ind"><span>1200 <small>ккал/день</small></span><b>1250 <small>руб.</small></b></div><div class="col-6 ind"><span>1600 <small>ккал/день</small></span><b>1450 <small>руб.</small></b></div></div>';
    $sql = "SELECT `name`,`textcorp`,`images` FROM `corpfood` WHERE `parent`='blocks' ORDER BY `sort` ASC";
    $res = $mysqli->query($sql) or die('Connect Error (' . $mysqli->connect_errno . ') ' . $mysqli->connect_error);
    echo '<div class="wrap">';
    while($result = $res->fetch_assoc()){
        echo '<div class="col-3"><div class="head-top center"><img src="/main/image/food-corporate/'.$result['images'].'" alt="'.$result['name'].'"><h3>'.$result['name'].'</h3></div><div class="text-corp">'.$result['textcorp'].'</div></div>';
    };
    echo '</div></div>';
};

function event_prev($mysqli){
    $sql = "SELECT `title`,`desc`,`img`,`url` FROM `event_desc` ORDER BY `id` DESC";
    $res = $mysqli->query($sql) or die('Connect Error (' . $mysqli->connect_errno . ') ' . $mysqli->connect_error);
    while ($result = $res->fetch_assoc()) {
        echo '<div class="col-1 border-indent"><div class="green-border photo"><a href="/event/'.$result['url'].'" class="img"><img src="/main/image/event/small/'.$result['img'].'" alt="'.$result['title'].'"><b><span>Подробнее</span></b></a><a href="/event/'.$result['url'].'">'.$result['title'].'</a><div class="prevtext">'.$result['desc'].'</div></div></div>';
    }
};

function event_customer($mysqli){
    $data = $_POST['data'];
    $customer_name = $data['nameC'];
    $customer_phone = $data['phoneC'];
    $customer_email = $data['emailC'];
    $customer_time = $data['timeC'];
    $link = '<a href="/event/priglasi-druga/" target="_blank">Идеальный друг</a>';
    $sql = "INSERT INTO `ordersday`(`name`,`email`,`phone`,`program`,`numday`,`calltime`,`growth`,`weight`,`age`,`desiredweight`,`city`,`status`) VALUES ('".$customer_name."','".$customer_email."','".$customer_phone."','".$link."',0,'".$customer_time."',0,0,0,0,'Москва',0)";
    $res = $mysqli->query($sql) or die('Connect Error (' . $mysqli->connect_errno . ') ' . $mysqli->connect_error);
};

function event_friend($mysqli){
    $data = $_POST['data'];
    $customer_name = $data['nameC'];
    $customer_phone = $data['phoneC'];
    $customer_email = $data['emailC'];
    $customer_time = $data['timeC'];
    $link = '<a href="/event/priglasi-druga/" target="_blank">Идеальный друг</a>';
    $sql = "INSERT INTO `ordersday`(`name`,`email`,`phone`,`program`,`numday`,`calltime`,`growth`,`weight`,`age`,`desiredweight`,`city`,`status`) VALUES ('".$customer_name."','".$customer_email."','".$customer_phone."','".$link."',0,'".$customer_time."',0,0,0,0,'Москва',0)";
    $res = $mysqli->query($sql) or die('Connect Error (' . $mysqli->connect_errno . ') ' . $mysqli->connect_error);
    $friend_name = $data['nameF'];
    $friend_phone = $data['phoneF'];
    $sql = "INSERT INTO `ordersday`(`name`,`email`,`phone`,`program`,`numday`,`calltime`,`growth`,`weight`,`age`,`desiredweight`,`city`,`status`) VALUES ('".$friend_name."','','".$friend_phone."','друг ".$customer_name."',0,'',0,0,0,0,'Москва',0)";
    $res = $mysqli->query($sql) or die('Connect Error (' . $mysqli->connect_errno . ') ' . $mysqli->connect_error);
};

function popup_pr($mysqli){
    $sql = "SELECT `titleslide` FROM `newprograms` ORDER BY `extra_sort`";
    $result = $mysqli->query($sql) or die('Connect Error (' . $mysqli->connect_errno . ') ' . $mysqli->connect_error);
    while($res = $result->fetch_assoc()){
        echo '<option value="'.$res['titleslide'].'">'.$res['titleslide'].'</option>';
    }
}

?>