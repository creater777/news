$(document).ready(function(){
	var programs_url_array=[
	'',
		'vegan-post',
		'stabilniy-resultat',
		'bistry-resultat',
		'fitness-dieta',
		'stroinost-na-vsu-gizn',
		'idealno-individualno',
		];
	var programs_title_array=[
	'',
		'Программа питания "Вегетарианство/пост" - Ideal Day',
		'Программа питания "Стабильный результат" - Ideal Day',
		'Программа питания "Быстрый результат" - Ideal Day',
		'Программа питания "Фитнес - диета" - Ideal Day',
		'Программа питания "Стройность на всю жизнь" - Ideal Day',
		'Программа питания "Идеально и индивидуально" - Ideal Day',
		];
	var comanda_url_array=[
        '',
        'ideal-wellness-couch',
        'ideal-komanda-povarov',
        'ideal-dietolog',
        ];
    var notNull = function(x){
        if(x >= 0){
            return x;
        }else{
            return 0;
        }
    };
    var popupBody = function(){
        if(screen.width >= 950){
            $('body').css({'overflow':'hidden','paddingRight':'17px'});
        }
    }
    function greenResize(){
        var greenHeight = $('.green-bg').innerHeight() / 2;
        $('.green-bg').css({'marginTop':-greenHeight+'px'});
    };
    function newsGreenResize(){
        var newsGrImg = $('a.img img');
        var newsGrB = $('a.img b');
        var newsGrHeight = [];
        newsGrImg.each(function(indx,element){
            newsGrHeight.push($(element).height());
        });
        newsGrB.css({'height':newsGrHeight[0]+'px','display':'block'});
    };
    setTimeout(function(){
        newsGreenResize();
    },5000);
    greenResize();

    var navLi = $('nav li');
    if(navLi.find('ul')){
        navLi.find('ul').parent().find('a').addClass('down');
        navLi.find('ul').find('li').find('a').removeClass('down');
        navLi.find('.down').click(function(){
            if($(this).hasClass('active')){
                $(this).removeClass('active').parent().find('ul').slideUp(300);
            }else{
                $(this).addClass('active').parent().find('ul').slideDown(300);
            }
            return false;
        })
    };

    // navigationActive
    var urlPage = document.location.href;
    var parAct = function(v){
        var liNav = v.parent('li');
        if(liNav.context.className === 'pink'){
            liNav.parent('ul').slideDown(550);
            liNav.parent('ul').parent('li').find('a').addClass('active');
        }
    };
    $('nav a').each(function(e){
        if(urlPage === this.href){
            $(this).addClass('pink');
        };
        parAct($(this));
    });
    $('footer li a').each(function(e){
        if(urlPage.indexOf(this.href)>=0){
            $(this).addClass('pink');
        }
    });

    var mainBlock = $('.main');
    mainBlock.css({'right':'0'});
    $('header .nav a').click(function(){
        var widthMain = parseInt(mainBlock.css('right'));
        if (widthMain == 0){
            $(this).addClass('active');
            mainBlock.animate({'right':'-300px'});
        }else{
            $(this).removeClass('active');
            mainBlock.animate({'right':'0'});
        };
        return false;
    });

    // sliderPartners
    var numLogo = $('.partners .col-5').length;
    var widhtLogoSlider = numLogo * 20;
    var widhtSlideLogo = 20 / (widhtLogoSlider / 100);
    var maxLogoMargin = widhtLogoSlider - 100;
    if(numLogo > 5){
        $('.partners .col-1').css({'width':widhtLogoSlider+'%'});
        $('.partners .col-5').css({'width':widhtSlideLogo+'%'});
        setInterval(function(){
            $('.partners .col-1').animate({'left':'-=20%'},300,function(){
            var ml = parseInt($('.partners .col-1').attr('style').replace(/([\%][^\n]*(\n|$))\w+\:\s/g,'').replace(/\w+\:\s/g,''));
            var mx = Math.round((parseFloat($('.partners .col-1').attr('style').replace(/([^\d\-\.])/g,'').replace(/^[^\-]+[\-]/g,'')) / 10) * 10);
            if(ml < 100+mx){
                $('.partners .col-1').animate({'left':'0px'},300);
            };
        })},5000);
    };
    function wPImg(){
        var wPartnerA = $('.partners .col-5').width();
        $('.partners a').css({'width':wPartnerA+'px'});
        var wPartnerImg = ($('.partners').width() / 5) / 2;
        $('.partners .col-5 img').css({'maxWidth':wPartnerImg+'px'});
    };
    wPImg();

    // program
    var progNext = $('.program-slider').find('.next');
    var progPrev = $('.program-slider').find('.prev');
    var wrapMainProg = $('.program-slider').find('ul');
    var oneProg = wrapMainProg.find('li');
    var numMainProg = oneProg.length;
    var widthMainProg = numMainProg * 33.333333330;
    var widthOneProg = 33.333333330 / (widthMainProg / 100);
    wrapMainProg.css({'width':widthMainProg+'%'});
    oneProg.css({'width':widthOneProg+'%'});
    	wrapMainProg.find('li:first').addClass('one');
    	wrapMainProg.find('li:eq(2)').addClass('three');
    var frontMainProg = $('.front-slider').find('.wrap');
    var frontOneProg = frontMainProg.find('.front-slide');
    var FrontNumProg = frontOneProg.length;
    var widthFrontProg = FrontNumProg * 250;
    frontMainProg.css({'width':widthFrontProg+'px'});
    frontMainProg.find('#front-1').appendTo(frontMainProg);
    if(typeof $active_programs_slide !== 'undefined'){
    	if($active_programs_slide>2){
    		$diif_index = $active_programs_slide - 2;
    		for($i=0;$i<$diif_index;$i++){
    			if(!wrapMainProg.is(':animated')){
                frontMainProg.animate({'left':'-250px'},0,function(){
                    frontMainProg.find('.front-slide:first').appendTo(frontMainProg).parent().css({'left':'0'});
                });
                wrapMainProg.animate({'left':'-33.333333330%'},0,function(){
                    wrapMainProg.find('li:eq(2)').removeClass('three')
                        .parent().find('li:first').removeClass('one').appendTo(wrapMainProg)
                        .parent().find('li').removeClass('active')
                        .parent().css({'left':'0'}).find('li:first').addClass('one')
                        .parent().find('li:eq(2)').addClass('three')
                        .parent().find('li:eq(1)').addClass('active');
                    orderPr();
                    newProg();
                });
               }
         	}
       } else {
       	$('li#slide-'+$active_programs_slide+',#prinfo-'+$active_programs_slide+'.program-info').addClass('active');
       }

    } else {
    	$('li#slide-2,#prinfo-2.program-info').addClass('active');
    }


    function minWidthFrontProg(){
        var docWidth = $(window).width();
        var slWidth = $('.program-slider').width();
        if(docWidth <= 700){
            $('.front-slider').css({'width':slWidth+'px'}).find('.wrap').find('.front-slide').css({'width':slWidth+'px'}).find('a').css({'width':slWidth+'px'});
        }else{
            $('.front-slider').css({'width':'250px'}).find('.wrap').find('.front-slide').css({'width':'250px'}).find('a').css({'width':'250px'});
        }
    };
    minWidthFrontProg();
    $('.program-info').find('div').find('b').find('span').each(function(){
        if($(this).text() == ''){
            $(this).parent().find('span.slash').remove();
        }
    });
    // Comments
    function comments(){
        $('.comment').find('.green-border').each(function(i){
            var cDesc = $(this).find('.discription');
            var cTitleH = $(this).find('.discription').find('h3').outerHeight();
            var cTextH = cDesc.find('p').outerHeight();
            var cNorm = 240 - cTitleH;
            var cUnderH = cDesc.find('a.under').outerHeight();
            if(cTextH <= cNorm){
                cDesc.find('a.under').addClass('none');
                cDesc.find('p').removeAttr('style');
            }else{
                if(cDesc.find('a.under').hasClass('none')){
                    cDesc.find('a.under').removeClass('none');
                }
                cDesc.find('p').css({'height':((cNorm-cUnderH)-14)+'px'});
                cDesc.find('a.under').click(function(){
                    if($(this).hasClass('active')){
                        $(this).removeClass('active').text('Подробнее');
                        cDesc.find('p').css({'height':((cNorm-cUnderH)-14)+'px'});
                    }else{
                        $(this).addClass('active').text('Скрыть');
                        cDesc.find('p').removeAttr('style');
                    }
                    return false;
                })
            }
        })
    };
    function com(){
        if($('.content').hasClass('programs')){
            var oneProgId = wrapMainProg.find('li.active').attr('id').replace(/[a-z\-]/g, "");
            $('.comment').each(function(){
                comId = $(this).attr('id').replace(/[a-z\-]/g, "");
            });
            if(oneProgId == comId){
                $('.comment#com-'+oneProgId).removeClass('none');
                comments();
            }
        }else{
            comments();
        }
    };
    com();
    function newProg(){
        var oneProgId = wrapMainProg.find('li.active').attr('id').replace(/[a-z\-]/g, "");
        if(oneProg.hasClass('active')){
            $('.program-info').removeClass('active');
            $('#prinfo-'+oneProgId).addClass('active');
        };
        $('.comment').each(function(){
            $(this).addClass('none');
            var comId = $(this).attr('id').replace(/[a-z\-]/g, "");
            if(oneProgId == comId){
                $('.comment#com-'+comId).removeClass('none');
                comments();
            }
        })
    };
    function orderPr(){
        var namePr = wrapMainProg.find('li.active').find('a').text();
        $('#your-pr').text(namePr).prev().val(namePr);
    };
    orderPr();
    function programNext(click){
        click.click(function(){
        	var pr_id = wrapMainProg.find('li.active').next().attr('id').replace(/[a-z\-]/g, "");
        	if (window.history.replaceState) {
        		window.history.replaceState(programs_url_array[pr_id], programs_title_array[pr_id], 'http://ideal-day.com/programs/'+programs_url_array[pr_id]+'/');
           	}
            if(!wrapMainProg.is(':animated')){
                frontMainProg.animate({'left':'-250px'},300,function(){
                    frontMainProg.find('.front-slide:first').appendTo(frontMainProg).parent().css({'left':'0'});
                });
                wrapMainProg.animate({'left':'-33.333333330%'},300,function(){
                    wrapMainProg.find('li:eq(2)').removeClass('three')
                        .parent().find('li:first').removeClass('one').appendTo(wrapMainProg)
                        .parent().find('li').removeClass('active')
                        .parent().css({'left':'0'}).find('li:first').addClass('one')
                        .parent().find('li:eq(2)').addClass('three')
                        .parent().find('li:eq(1)').addClass('active');
                    orderPr();
                    newProg();
                });
            }
            return false;
        })
    };
    function programPrev(click){
        click.click(function(){
        	var pr_id = wrapMainProg.find('li.active').prev().attr('id').replace(/[a-z\-]/g, "");
        	if (window.history.replaceState) {
        		window.history.replaceState(programs_url_array[pr_id], programs_title_array[pr_id], 'http://ideal-day.com/programs/'+programs_url_array[pr_id]+'/');
           }
            if(!wrapMainProg.is(':animated')){
                frontMainProg.css({'left':'-250px'}).find('.front-slide:last').prependTo(frontMainProg).parent().animate({'left':'0'},300);
                wrapMainProg
                    .css({'left':'-33.333333330%'}).find('li:eq(2)').removeClass('three')
                    .parent().find('li:first').removeClass('one')
                    .parent().find('li:last').prependTo(wrapMainProg)
                    .parent().find('li').removeClass('active')
                    .parent().animate({'left':'0'},300,function(){
                        wrapMainProg.find('li:eq(2)').addClass('three')
                            .parent().find('li:first').addClass('one')
                            .parent().find('li:eq(1)').addClass('active');
                        orderPr();
                        newProg();
                    })
            }
            return false;
        })
    };
    programNext(progNext);
    programPrev(progPrev);

    // popUp
    var link = $('a#checkout');
    var popUp = $('.main-pop-up');

    if($('.content').hasClass('one-pr')){
        link.css({'height':'36px','padding':'57px 0'}).find('span').remove();
    }

    function popUpNew (link,popup) {
        link.click(function(){
            $('.main-pop-up').fadeIn(300);
            popupBody();
            function popupPos(){
                var windowWidth = $(window).width();
                var windowHeight = $(window).height();
                var popUpClass = $('.main-pop-up .pop-up');
                var popUpWidth = popUpClass.innerWidth();
                var popUpHeight = popUpClass.innerHeight();
                var popUpLeftPos = (windowWidth - popUpWidth) / 2;
                var popUpTopPos = (windowHeight - popUpHeight) / 2;
                popUpClass.css({
                    'left': notNull(popUpLeftPos)+'px',
                    'top': notNull(popUpTopPos)+'px'
                });
            };
            popupPos();
            $(window).resize(function(){popupPos();});
            $('.main-pop-up .bg-close, .main-pop-up span').click(function(){
                $('.main-pop-up').fadeOut(300,function(){
                    $('body').removeAttr('style');
                });
            });
            return false;
        });
    };
    popUpNew(link,popUp);

    // pop-up slider
    var fb = '.slider-ui';
    if($('.content').hasClass('white-menu')){
        var textWhite = $('#order').find('p').find('strong').text();
        $('#program').val(textWhite);
        $(fb+' #slider').slider({
            value: 3,
            range: 'min',
            min: 3,
            max: 30,
            step: 1,
            slide: function(event,ui){
                $('#num-day').val(ui.value);
                $('.ui-slider-handle').find('i').text(ui.value);
                var iVal = $('#num-day').val();
                if(iVal == iVal){
                    $('.slider-text p').removeClass('active');
                    $('.slider-text .nth-'+iVal).addClass('active');
                };
                if(ui.value == 3){
                    $('.pop-up .slider-text .nth-3').addClass('none');
                }else if(ui.value == 30){
                    $('.pop-up .slider-text .nth-30').addClass('none');
                }else{
                    $('.pop-up .slider-text p').removeClass('none');
                }
            }
        })
    }else if($('.content').hasClass('food-corp')){
        $(fb+' #slider').slider({
            value: 1,
            range: 'min',
            min: 0,
            max: 30,
            step: 10,
            slide: function(event,ui){
                $('#num-day').val(ui.value);
                var iVal = $('#num-day').val();
                if(iVal == iVal){
                    $('.slider-text p').removeClass('active');
                    $('.slider-text .nth-'+iVal).addClass('active');
                }
            }
        })
    }else{
        $(fb+' #slider').slider({
            value: 10,
            range: 'min',
            min: 0,
            max: 30,
            step: 10,
            slide: function(event,ui){
                $('#num-day').val(ui.value);
                var iVal = $('#num-day').val();
                if(iVal == iVal){
                    $('.slider-text p').removeClass('active');
                    $('.slider-text .nth-'+iVal).addClass('active');
                };
                switch(iVal){
                    case '0':
                        $('.pop-up .slider-ui strong b').text(' ')
                    break
                    case '10':
                        $('.pop-up .slider-ui strong b').text('+ Подарок')
                    break
                    case '20':
                        $('.pop-up .slider-ui strong b').text('+ 2 дня в подарок')
                    break
                    case '30':
                        $('.pop-up .slider-ui strong b').text('+ 3 дня в подарок')
                    break
                }
            }
        })
    };
    $('#num-day').val($('#slider').slider('value'));

    // validate
    var validName = /^([\ba-zа-я\.'\b+]){2,15}([ ]?){0,1}([\ba-zа-я-\.'\b+]?){1,15}([ ]?){0,1}([\ba-zа-я-\.'\b+]?){1,15}$/img;
    var validEmail = /^([\w\.\-_]+)?\w+@[\w-_]+(\.\w+){1,}$/igm;
    var validPhone = /^([\++]?){0,1}([0-9]){9,13}$/;
    var validAge = /^[0-9]{2,3}$/im;
    var validGrowth = /^[0-9]{2,3}$/im;
    var validWeight = /^[0-9]{2,3}$/im;
    var validdesiredWeight = /^[0-9]{2,3}$/im;

    function validSelect(formSelect){
        var select = formSelect;
        if(select.val() == null){
            errors = true;
            select.removeClass('valid');
            select.addClass('error');
        }else{
            select.removeClass('error');
            select.addClass('valid');
        }
    };
    function validate(form,valid){
        function validForm(){
            if(form.val() != ''){
                if(form.val().search(valid) == 0){
                    form.removeClass('error').addClass('valid');
                }else{
                    form.removeClass('valid').addClass('error');
                }
            }else{
                form.removeClass('valid').addClass('error');
            }
        };
        form.blur(function(){
            validForm();
        });
        form.keyup(function(){
            validForm();
        });
    };

    // ajaxForm
    function ajaxForm(form,handler){
        form.submit(function(){
            var errors = false;
            $(this).find('input:not(#submit),select').each(function(){
                if($.trim($(this).val()) == ''){
                    errors = true;
                    $(this).addClass('error');
                }else{
                    $(this).removeClass('error');
                    $(this).addClass('valid');
                };
                validSelect(form.find('select'));
                validSelect(form.find('p').find('select'));
            });
            if(!errors){
                var data = form.serialize();
                $.ajax({
                    url: '/main/processing/'+handler+'.php',
                    type: 'POST',
                    data: data,
                    beforeSend: function(){
                        form.find('small').text('Отправляю...');
                    },
                    success: function(res){
                        if(res == 1){
                            form.find('input:not(#submit)').val('');
                            form.find('input:not(#submit)').removeClass('valid');
                            form.find('small').text('Спасибо! Ваш заказ принят!');
                        }else{
                            form.find('small').text('Ошибка отправки');
                        }
                    },
                    error: function(){
                        form.find('small').text('Ошибка отправки');
                    }
                });
            };
            return false;
        });
    }

    // send
    var order = $('#order');
    var quest = $('#quest');
    var name = $('#name');
    var email = $('#email');
    var phone = $('#phone');
    var nameContact = $('#name-contact');
    var emailContact = $('#email-contact');
    var phoneContact = $('#phone-contact');
    var age = $('#age');
    var growth = $('#growth');
    var weight = $('#weight');
    var phoneQuest = $('#phone-quest');
    var ageQuest = $('#age-quest');
    var growthQuest = $('#growth-quest');
    var weightQuest = $('#weight-quest');
    var desiredWeight = $('#desired-weight');

    validate(name,validName);
    validate(email,validEmail);
    validate(phone,validPhone);
    validate(nameContact,validName);
    validate(emailContact,validEmail);
    validate(phoneContact,validPhone);
    validate(age,validAge);
    validate(growth,validGrowth);
    validate(weight,validWeight);
    validate(phoneQuest,validPhone);
    validate(ageQuest,validAge);
    validate(growthQuest,validGrowth);
    validate(weightQuest,validWeight);
    validate(desiredWeight,validdesiredWeight);

    ajaxForm(order,'order');
    ajaxForm(quest,'questionnaire');

    // Inset
    if(typeof $comanda_page !== 'undefined'){
    	$('.inset').find('a:nth-child('+$comanda_page+')').addClass('active');
    	$('#info-'+$comanda_page).addClass('active');
    } else {
    	$('.inset').find('a:first').addClass('active');
    	$('#info-1').addClass('active');
    }


    $('.inset').find('a').click(function(){
        var idLink = $(this).attr('id').replace(/[a-z\-]/g, "");
        if (window.history.replaceState) {
        	window.history.replaceState(comanda_url_array[idLink], 'Наша команда - Ideal Day', 'http://ideal-day.com/company/nasha-comanda/'+comanda_url_array[idLink]+'/');
        }
        if($(this).hasClass('active')==false){
            $('.inset').find('a').removeClass('active');
            $('.green-border').removeClass('active');
            $('#info-'+idLink).addClass('active');
            $(this).addClass('active');
        };
        return false;
    });

    // About Us Height
    $('.about-us .pink-bg-op .col-5:last').addClass('two').prev().addClass('two');
    function oneHeightElement(parent,elem){
        var winWid = $(window).width();
        var parentElemUs = $('.about-us .pink-bg-op .col-5 p');
        var lElemUs = $('.about-us .pink-bg-op .col-5:last p').height();
        var fElemUs = $('.about-us .pink-bg-op .col-5:first p').height();
        if(winWid >= 1600){
            parentElemUs.css({'height':lElemUs+'px'});
            $('.about-us .col-5:last p').removeAttr('style');
        }else if(winWid >= 750 & winWid <= 1600){
            parentElemUs.css({'height':fElemUs+'px'});
            $('.about-us .col-5:first p').removeAttr('style');
        }else{
            $('.about-us .col-5 p').removeAttr('style');
        }
    };
    oneHeightElement();

    // CorpFood
    $('.corp-food .col-3:last').addClass('two').prev().addClass('two');

    // photoGallery
    var photoGallery = function(){
        if($('#gallery')){
            var pgLink = $('#gallery a');
            var allArr = [];
            pgLink.each(function(e){
                var pgData = $(this).data();
                if(isFinite(pgData.sort)){
                    allArr.push(pgData.sort)
                }
            });
            pgLink.click(function(){
                $('body').append('<div class="bg-load"><div class="loader"></div></div>');
                var pgData = $(this).data();
                var url = $(this).find('img').attr('src').replace(/prev/, 'large');
                var title = $(this).find('img').attr('alt');
                var pgWpgW = function(){
                    var pgW = window.innerWidth;
                    var pgH = window.innerHeight;
                    var pgWrap = $('.img-gallery').find('.wrap');
                    pgImg = pgWrap.find('img');
                    $('.img-gallery').css({'width':pgW+'px','height':pgH+'px'});
                    $('.img-gallery').append('<div class="bg-load"><div class="loader"></div></div>');
                    pgImg.css({'maxWidth':(pgW-20)+'px','maxHeight':(pgH-60)+'px'});
                    var imgWidth = function(){
                        if((pgImg.width()+90) >= pgW){
                            pgWrap.find('a').addClass('in');
                        }else{
                            pgWrap.find('a').removeClass('in');
                        }
                    };
                    pgImg.load(function(){
                        pgWrap.find('.info').css({'width':(pgImg.width()-20)+'px'});
                        $('.img-gallery .prev,.img-gallery .next').css({'height':pgImg.height()+'px'});
                        $('.img-gallery .close,.img-gallery .prev,.img-gallery .next,.img-gallery .info').addClass('active');
                        $('.img-gallery').find('.bg-load').remove();
                        imgWidth();
                    });
                    pgWrap.find('.info').css({'width':(pgImg.width()-20)+'px'});
                    $('.img-gallery .prev,.img-gallery .next').css({'height':pgImg.height()+'px'});
                    imgWidth();
                };
                if(isFinite(pgData.sort)){
                    if(allArr.length > 1){
                        var prevNext = '<a href="#" class="prev"><b><</b></a><a href="#" class="next"><b>></b></a>';
                    }else{
                        var prevNext = '';
                    };
                    var pgContent = '<div class="photo-popup"><div class="bg-pop-up"><div class="img-gallery"><div class="bg-close"></div><div class="wrap" data-num="'+pgData.sort+'">'+prevNext+'<a href="#" class="close">&times;</a><img src="'+url+'" alt="'+title+'"><div class="info"><p><b>'+title+' ('+pgData.sort+' / '+allArr.length+')</b></p></div></div></div></div></div>';
                    var pgC = $('body').append(pgContent);
                    pgC.onload = function(){
                        $('.bg-load').remove();
                        $('.photo-popup').next('.photo-popup').remove();

                        popupBody();
                        if(screen.width >= 950){
                            $('.photo-popup').fadeIn(300);
                        }else{
                            $('.photo-popup').css({'display':'block'});
                        };
                        pgWpgW();
                        if($('.img-gallery')){
                            $(window).resize(function(){
                                pgWpgW();
                                $('.img-gallery').find('.bg-load').remove();
                            })
                        };
                        // close
                        $('.img-gallery .close,.bg-close').click(function(){
                            if(window.innerWidth >= 950){
                                $('.photo-popup').fadeOut(300,function(){
                                    $('.photo-popup').remove();
                                    $('body').removeAttr('style');
                                });
                            }else{
                                $('.photo-popup').css({'display':'none'});
                                $('.photo-popup').remove();
                                $('body').removeAttr('style');
                            };
                            return false;
                        });
                        // next / prev
                        var next = $('.img-gallery').find('.wrap').find('.next');
                        var prev = $('.img-gallery').find('.wrap').find('.prev');
                        var numEl = $('.img-gallery').find('.wrap').data();
                        var param = {
                            count: numEl.num,
                            count2: numEl.num
                        };
                        var urlTitle = function(){
                            pgLink.each(function(e){
                                var pgData = $(this).data();
                                if(pgData.sort === param.count){
                                    param.url = $(this).find('img').attr('src').replace(/prev/, 'large');
                                    param.title = $(this).find('img').attr('alt');
                                }
                            });
                        };
                        var pgAnim = function(n1,n2){
                            $('.img-gallery').find('.wrap').animate({
                                'left':n1,
                                'opacity':'0'
                            },{
                                duration:200,
                                specialEasing:{
                                    'left':'swing',
                                    'opacity':'swing'
                                },
                                complete:function(){
                                    param.count2 = param.count;
                                    $(this).css({'left':n2});
                                    $(this).find('img').remove();
                                    $(this).find('a').removeClass('active');
                                    $(this).find('.info').removeClass('active');
                                    $(this).find('.close').after('<img src="'+param.url+'" alt="'+param.title+'">');
                                    pgWpgW();
                                    $(this).find('.info').find('p').find('b').text(param.title+' ('+param.count+' / '+allArr.length+')');
                                    $(this).animate({
                                        'left':'0px',
                                        'opacity':'1'
                                    },{
                                        duration:200,
                                        specialEasing:{
                                            'left':'swing',
                                            'opacity':'swing'
                                        }
                                    })
                                }
                            })
                        };
                        var pgFin = function(n){
                            $('.img-gallery').find('.wrap').animate({
                                'left':n,
                                'opacity':'0.5'
                            },{
                                duration:150,
                                specialEasing:{
                                    'left':'swing',
                                    'opacity':'swing'
                                },
                                complete:function(){
                                    $(this).animate({
                                        'left':'0px',
                                        'opacity':'1'
                                    },{
                                        duration:150,
                                        specialEasing:{
                                            'left':'swing',
                                            'opacity':'swing'
                                        }
                                    })
                                }
                            })
                        }
                        next.on('click', function(){
                            param.count++;
                            if(param.count >= allArr.length){
                                param.count = allArr.length;
                            };
                            urlTitle();
                            if(param.count2 < allArr.length){
                                pgAnim(-(window.innerWidth / 2)+'px',pgImg.width()+'px');
                            }else{
                                pgFin(-(window.innerWidth / 4)+'px');
                            };
                            return false;
                        });
                        prev.on('click', function(){
                            param.count--;
                            if(param.count == 0){
                                param.count = 1;
                            };
                            urlTitle();
                            if(param.count2 > 1){
                                pgAnim((window.innerWidth / 2)+'px',-pgImg.width()+'px');
                            }else{
                                pgFin((window.innerWidth / 4)+'px');
                            };
                            return false;
                        });
                    };
                    pgC.onload();
                    return false;
                }
            })
        }
    };
    photoGallery();

    // Resize
    $(window).resize(function(){
        newsGreenResize();
        greenResize();
        wPImg();
        minWidthFrontProg();
        oneHeightElement();
        $('.comment').find('.green-border').each(function(i){
            $(this).find('.discription').find('p').removeAttr('style');
            $(this).find('.discription').find('a.under').removeClass('none').text('Подробнее');
        });
        com();
        photoGallery();
    });
});