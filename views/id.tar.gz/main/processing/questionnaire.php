<?php
    require "../lib/ideal_db.php";
    require "../lib/func_lib.php";
    if($_POST){

        $age = $_POST['age'];
        $growth = $_POST['growth'];
        $weight = $_POST['weight'];
        $phone = $_POST['phone'];
        $city = 'Москва';
        $program = 'Анкета';
        $ip = $_SERVER['SERVER_ADDR'];

        // admin panel
        save_quest($age,$growth,$weight,$phone,$program,$city,$mysqli);
        

        // mail
        $formcontent="У Вас новая анкета<br><br>Возраст клинта: $age<br>Рост клиента: $growth<br>Вес клиента: $weight<br>Номер телефона клиента: $phone";
        $recipient = "ideal.day2015@yandex.ru";
        $subject = "У Вас новая анкета";
        $headers= "MIME-Version: 1.0\r\n";
        $headers .= "Content-type: text/html; charset=utf-8\r\n";
        $headers .= "From: Ideal Day <info@ideal-day.com> \r\n";

        if($ip == '127.0.0.1'){
            $mail_result = true;
        }else{
            $mail_result = mail($recipient, $subject, $formcontent, $headers);
        }

        if($mail_result === true){
            $answer = '1';
        }else{
            $answer = '0';
        }
        die($answer);
    }
?>