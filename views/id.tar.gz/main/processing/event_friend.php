<?php
    $root = $_SERVER['DOCUMENT_ROOT'];
    require $root.'/main/lib/ideal_db.php';
    require $root.'/main/lib/func_lib.php';

    if($_POST){
        if($_POST['data']['friend'] == 'noactive'){
            event_customer($mysqli);
        }else{
            event_friend($mysqli);
        }
        echo '1';
    }else{
        echo '0';
    }
?>