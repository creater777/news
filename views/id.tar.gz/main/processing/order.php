<?php
    require "../lib/ideal_db.php";
    require "../lib/func_lib.php";
    if($_POST){

        $program = $_POST['program'];
        $name = $_POST['name'];
        $email = $_POST['email'];
        $phone = $_POST['phone'];
        $time = $_POST['time'];
        $growth = $_POST['growth'];
        $weight = $_POST['weight'];
        $age = $_POST['age'];
        $desired_weight = $_POST['desired_weight'];
        $day = $_POST['num_day'];
        $num_day = '0';
        $city = 'Москва';
        $ip = $_SERVER['SERVER_ADDR'];


        switch($day){
            case 0:
                $num_day = '1';
                break;
            case 10:
                $num_day = '10';
                break;
            case 20:
                $num_day = '21';
                break;
            case 30:
                $num_day = '30';
                break;
        }

        if($program == 'White Menu'){
            $num_day = $day;
        }

        // admin panel
        save_order($name,$email,$phone,$program,$num_day,$time,$growth,$weight,$age,$desired_weight,$city,$mysqli);
        

        // mail
        $formcontent="У Вас новый заказ<br><br>Выбранная программа: $program<br>Имя клиента: $name<br>Email клиента: $email<br>Номер телефона клиента: $phone<br>Удобное время для связи: $time<br>Рост клиента: $growth<br>Вес клиента: $weight<br>Возраст клинта: $age<br>Желаемый вес клиента: $desired_weight<br>Количество дней: $num_day";
        $recipient = "ideal.day2015@yandex.ru";
        $subject = "У Вас новый заказ";
        $headers= "MIME-Version: 1.0\r\n";
        $headers .= "Content-type: text/html; charset=utf-8\r\n";
        $headers .= "From: Ideal Day <info@ideal-day.com> \r\n";


        if($ip == '127.0.0.1'){
            $mail_result = true;
        }else{
            $mail_result = mail($recipient, $subject, $formcontent, $headers);
        }

        if($mail_result === true){
            $answer = '1';
        }else{
            $answer = '0';
        }
        die($answer);
    }
?>