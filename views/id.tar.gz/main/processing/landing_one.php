<?php
    require "../lib/ideal_db.php";
    require "../lib/func_lib.php";
    if($_POST){

        $program = '<a href="/event/zdorovoe-corporativnoe-pitanie/" target="_blank">Ideal Day 5+</a>';
        $name = $_POST['name'];
        $email = $_POST['email'];
        $phone = $_POST['phone'];
        $time = $_POST['time'];
        $city = 'Москва';
        $ip = $_SERVER['SERVER_ADDR'];

        // admin panel
        landing_one($name,$email,$phone,$program,$time,$city,$mysqli);
        

        // mail
        $formcontent="У Вас новый заказ<br><br>Выбранная программа: $program<br>Имя клиента: $name<br>Email клиента: $email<br>Номер телефона клиента: $phone<br>Удобное время для связи: $time";
        $recipient = "ideal.day2015@yandex.ru";
        $subject = "У Вас новый заказ";
        $headers= "MIME-Version: 1.0\r\n";
        $headers .= "Content-type: text/html; charset=utf-8\r\n";
        $headers .= "From: Ideal Day <info@ideal-day.com> \r\n";

        if($ip == '127.0.0.1'){
            $mail_result = true;
        }else{
            $mail_result = mail($recipient, $subject, $formcontent, $headers);
        }

        if($mail_result === true){
            $answer = '1';
        }else{
            $answer = '0';
        }
        die($answer);
    }
?>